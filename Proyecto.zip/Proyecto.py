#from Libraries.validaciones import *
from tkinter import *
from tkinter import messagebox
from tkinter import ttk
import os
import time
#from tkinter import pillow
from PIL import Image, ImageTk
import sqlite3
from tqdm.auto import tqdm 
from datetime import datetime
from tkcalendar import Calendar
#from matplotlib import pyplot as plt
#from ttkthemes import ThemedStyle
conexion = sqlite3.connect("LifeHealth.db")
#pillow(imagenes)
#reportlab(pdfs)
#cerberus(validaciones)
nombrePrograma = "Life Health"

def misEstilos():
	global estilos
	color_navegacion="black"
	color_navegacion2= 'SkyBlue4'
	estilos = ttk.Style()
	estilos.theme_use("alt")
	estilos.configure("programa.TLabel",
					  background="black",

					  foreground="ivory3",
					  font=('Georgia',50,"italic","bold")
					 )
	estilos.configure("tituloLogin.TLabel",
					  background= 'black',
					  foreground='plum4',
					  font=("Georgia",30,"italic","bold")
					 )
	estilos.configure("subTitulo.TLabel",
					  background= 'black',
					  foreground='snow',
					  font=('Georgia',15,"bold")
					 )
	estilos.configure("labelNavegacion.TLabel",
					  background= 'ivory3',
					  foreground='black',
					  font=('Georgia',15,"bold"))
	estilos.configure("entradasNavegacion.TLabel",
					  background= 'snow',
					  foreground='black',
					  font=('Georgia',20,"bold"))
	
	estilos.configure("frameSecundarios.TFrame",
					  background= 'black',
					  relief=FLAT,border=0)
	estilos.configure("frameTerciarios.TFrame",
					  background= 'SkyBlue4',
					  relief=FLAT,border=0)

	estilos.configure("entradasLogin.TLabel",
					  background='snow',
					  foreground='black',
					  font=('Calibri',20)
					 )
	estilos.configure("entradasNavegacion2.TLabel",
					  background='ivory3',
					  foreground='black',
					  font=('Calibri',25)
					  )
	estilos.configure('login.TFrame',background='black',relief=FLAT,border=0)
	estilos.configure('loginCentrado.TFrame',background='SkyBlue4',relief=FLAT,border=0)

	estilos.configure('fondo.TFrame',background='Black',relief=FLAT,border=0)
	estilos.configure('principal.TFrame',background='snow',relief=FLAT,border=0)
	estilos.configure('navegacion.TFrame',background="SkyBlue4",relief=FLAT,border=0)
	estilos.configure('botonLabel.TLabel',foreground='snow',
					  font=('Calibri',24),
					  background=color_navegacion,
					  relief=FLAT,border=0)
	estilos.configure('botonNavegacion.TButton',
   					  background="ivory3",
   					  foreground='black',
   					  font=('Georgia',12,"bold"),
   					  relief=FLAT,
   					  bd=0,
					 )
	estilos.map('botonNavegacion.TButton',
		       background=[('pressed',color_navegacion2),('active',color_navegacion2)])
	estilos.configure('botonLogin.TButton',
					  background="ivory3",
   					  foreground='black',
   					  font=('Georgia',20),
   					  relief=FLAT,
   					  bd=0,
					 )
	estilos.map('botonLogin.TButton',
		       background=[('pressed',color_navegacion2),('active',color_navegacion2)])
	return estilos

def validate_entry_numeros(content):
	return content.isdigit()

def validate_entry_letras_espacios(content):
	return content.isalpha() or content.isspace()

def login_principal():

	global login_principal
	global imagenLogoPrincipal	
	global ventana_principal

	ventana_principal.geometry("900x900")
	ventana_principal.title("LifeHealt")
	icono = PhotoImage(file ="icon.png")
	ventana_principal.iconphoto(True,icono)

	frame_login = ttk.Frame(ventana_principal,style='login.TFrame')
	frame_login.pack(fill=BOTH,expand=1)

	frame_login_centrado =ttk.Frame(frame_login,style='loginCentrado.TFrame')
	frame_login_centrado.pack(pady=80,ipady=40)

	label_login = ttk.Label(frame_login_centrado,text="**** LOGIN ****",style="tituloLogin.TLabel")
	label_login.pack(pady=20)

	imagenLogoPrincipal=PhotoImage(file="imagenLogo.png")
	label_Logo = Label(frame_login_centrado,image=imagenLogoPrincipal)
	label_Logo.pack(padx=90)

	def registro():
		global imagen_pil_volver_login
		global login_principal
		global frame_login_registro
		global nombre_usuario
		global clave
		global entry_usuario_registro
		global entry_contraseña_registro
		global entry_codigoRegistro
	
		nombre_usuario = StringVar()
		clave = StringVar()
		frame_login.pack_forget()

		frame_login_registro = ttk.Frame(ventana_principal,style='login.TFrame')
		frame_login_registro.pack(fill=BOTH,expand=1)

		frame_login_centrado_registro =ttk.Frame(frame_login_registro,style='loginCentrado.TFrame')
		frame_login_centrado_registro.pack(pady=100,ipady=60,ipadx=50)

		label_login_registro = ttk.Label(frame_login_centrado_registro,text="**** Log in ****",style="tituloLogin.TLabel")
		label_login_registro.pack(pady=30)
		
		label_usuario_registro = ttk.Label(frame_login_centrado_registro,text="     Usuario     ",style="subTitulo.TLabel")
		label_usuario_registro.pack(pady=10)
		entry_usuario_registro = ttk.Entry(frame_login_centrado_registro,textvariable=nombre_usuario,style="entradasLogin.TLabel",width=20,show="*")
		entry_usuario_registro.pack(pady=5,ipadx=10)
			    
		label_contraseña_registro = ttk.Label(frame_login_centrado_registro,text="  Contraseña  ",style="subTitulo.TLabel")
		label_contraseña_registro.pack(pady=10)
		entry_contraseña_registro = ttk.Entry(frame_login_centrado_registro,style="entradasLogin.TLabel",textvariable=clave,width=20,show="*")
		entry_contraseña_registro.pack(pady=5,ipadx=10)

		label_codigoRegistro = ttk.Label(frame_login_centrado_registro,text="   Código  ",style="subTitulo.TLabel")
		label_codigoRegistro.pack(pady=10)
		entry_codigoRegistro = ttk.Entry(frame_login_centrado_registro,style="entradasLogin.TLabel",width=20,show="*")
		entry_codigoRegistro.pack(pady=5,ipadx=10)
		#boton_registrar.config(state="disabled")

		imagen_pil_volver_login= Image.open("iconos/btnVolver.png")
		imagen_resize_volver_login = imagen_pil_volver_login.resize((30,30))
		imagen_tk_volver_login= ImageTk.PhotoImage(imagen_resize_volver_login)

		boton_volver_login= ttk.Button(frame_login_centrado_registro,text="VOLVER",style="botonNavegacion.TButton",command = volver_login_registro)
		boton_volver_login.config(image=imagen_tk_volver_login,compound=LEFT)
		boton_volver_login.image = imagen_tk_volver_login 
		boton_volver_login.pack(side=BOTTOM,padx=20,pady=10)
	
		boton_registrarse = ttk.Button(frame_login_centrado_registro,text="Registrarse",style='botonLogin.TButton',command=registro_usuario)
		boton_registrarse.pack(pady=20,side=BOTTOM)		
		
	def registro_usuario():
		global login_principal
		global frame_login_registro
		global imagenLogoPrincipal
		global file
		global usuario_info
		global clave_info
		global codigo

		usuario_info = entry_usuario_registro.get()
		clave_info = entry_contraseña_registro.get()
		codigo = entry_codigoRegistro.get()
		
		if not(usuario_info == "" or clave_info == "" or codigo == ""):

			file = open(usuario_info,"w")
			file.write(usuario_info + "/n")
			file.write(clave_info)
			entry_usuario_registro.delete(0,END)
			entry_contraseña_registro.delete(0,END)
			if (codigo==str(1234)):
				file.write(codigo)
				entry_codigoRegistro.delete(0,END)
				file.close()
				messagebox.showinfo("LifeHealth","Registro exitoso")
				frame_login_registro.pack_forget()
				login_principal()
			else:
				messagebox.showerror("LifeHealth","Error en código de registro")
				frame_login_registro.pack_forget()
				login_principal()
		else:	
			messagebox.showwarning("LifeHealth","¡Complete todos los campos!")
			frame_login_registro.pack_forget()
			login_principal()
	
	def volver_login_registro():
		global frame_login_registro
		global imagen_pil_volver_login
		frame_login_registro.pack_forget()
		login_principal()
			
	def login():
		global imagen_pil_volver_login
		global frame_login_acceso
		global entry_usuario_acceso
		global entry_contraseña_acceso

		frame_login.pack_forget()

		frame_login_acceso = ttk.Frame(ventana_principal,style='login.TFrame')
		frame_login_acceso.pack(fill=BOTH,expand=1)

		frame_login_centrado_acceso =ttk.Frame(frame_login_acceso,style='loginCentrado.TFrame')
		frame_login_centrado_acceso.pack(pady=100,ipady=60,ipadx=50)

		label_login_acceso= ttk.Label(frame_login_centrado_acceso,text="**** Log in ****",style="tituloLogin.TLabel")
		label_login_acceso.pack(pady=30)
	    
		label_usuario_acceso = ttk.Label(frame_login_centrado_acceso,text="     Usuario     ",style="subTitulo.TLabel")
		label_usuario_acceso.pack(pady=10)
		entry_usuario_acceso = ttk.Entry(frame_login_centrado_acceso,style="entradasLogin.TLabel",width=20,show="*")
		entry_usuario_acceso.pack(pady=5,ipadx=10)
			    
		label_contraseña_acceso = ttk.Label(frame_login_centrado_acceso,text="  Contraseña  ",style="subTitulo.TLabel")
		label_contraseña_acceso.pack(pady=10)
		entry_contraseña_acceso = ttk.Entry(frame_login_centrado_acceso,style="entradasLogin.TLabel",width=20,show="*")
		entry_contraseña_acceso.pack(pady=5,ipadx=10)

		imagen_pil_volver_login= Image.open("iconos/btnVolver.png")
		imagen_resize_volver_login = imagen_pil_volver_login.resize((30,30))
		imagen_tk_volver_login= ImageTk.PhotoImage(imagen_resize_volver_login)

		boton_volver_login= ttk.Button(frame_login_centrado_acceso,text="VOLVER",style="botonNavegacion.TButton",command = volver_login_acceso)
		boton_volver_login.config(image=imagen_tk_volver_login,compound=LEFT)
		boton_volver_login.image = imagen_tk_volver_login 
		boton_volver_login.pack(side=BOTTOM,padx=20,pady=10)

		boton_acceso = ttk.Button(frame_login_centrado_acceso,text="Ingresar",style='botonLogin.TButton',command=verificacion_login)
		boton_acceso.pack(pady=20,side=BOTTOM)

	def verificacion_login():
		global login_principal
		global frame_login_acceso
		global imagenLogoPrincipal
		global progressbar
		usuario = entry_usuario_acceso.get() 
		contraseña = entry_contraseña_acceso.get()
			
		entry_usuario_acceso.delete(0,END)
		entry_contraseña_acceso.delete(0,END)

		if not(usuario == "" or contraseña == ""):
			
			if(usuario == "1" and contraseña == "2"):
				messagebox.showinfo ("LifeHealth","Bienvenido/a")
				frame_login_acceso.pack_forget()
				barraCarga()
				frame_carga.pack_forget()			
				principal()	
			elif(usuario == "2" and contraseña == "3"):
				messagebox.showinfo ("LifeHealth","Bienvenido/a") 
				frame_login_acceso.pack_forget()
				barraCarga()
				frame_carga.pack_forget()			
				principal_empleado()
			else:
				messagebox.showerror("LifeHealth","Acceso denegado")
				frame_login_acceso.pack_forget()
				login_principal()
		else:
			messagebox.showwarning("LifeHealth","¡Complete todos los campos!")
			frame_login_acceso.pack_forget()
			login_principal()

	def volver_login_acceso():
		global frame_login_registro
		global imagen_pil_volver_login
		frame_login_acceso.pack_forget()
		login_principal()

	boton_registrar = ttk.Button(frame_login_centrado,text="Registro",style='botonLogin.TButton',command=registro).pack(pady=10,side=BOTTOM)
	boton_login = ttk.Button(frame_login_centrado,text="Acceso",style='botonLogin.TButton',command=login).pack(pady=10,side=BOTTOM)	

def barraCarga():
	global frame_carga
	global progressbar
	global imagenLogo

	frame_carga = ttk.Frame(ventana_principal,style='login.TFrame')
	frame_carga.pack(fill=BOTH,expand=1)
	frame_carga_centrado =ttk.Frame(frame_carga,style='loginCentrado.TFrame')
	frame_carga_centrado.pack(pady=80,ipady=40,ipadx=40)
	label_carga = ttk.Label(frame_carga_centrado,text="Cargando....",font=("Georgia",30),style="tituloLogin.TLabel")
	label_carga.pack(pady=40)
	imagenLogo=PhotoImage(file="imagenLogo.png")
	label_Logo = Label(frame_carga_centrado,image=imagenLogo)
	label_Logo.pack(padx=90)

	percent = StringVar()
	text = StringVar()

	progressbar = ttk.Progressbar(frame_carga_centrado,orient=HORIZONTAL,length=300)
	progressbar.pack(pady=70)

	percentLabel = ttk.Label(frame_carga_centrado, textvariable=percent,style="subTitulo.TLabel").pack(ipady=5,pady=5,padx=5)
	taskLabel = ttk.Label(frame_carga_centrado, textvariable=text,style="subTitulo.TLabel").pack(ipady=5,pady=5,padx=5)
	
	GB = 100
	descarga = 0
	speed = 1
	while(descarga<GB):
		time.sleep(0.08)
		progressbar ["value"]+=(speed/GB)*100
		descarga+=speed
		percent.set(str(int(descarga/GB)*100)+"%")
		text.set(str(descarga)+" Completando ")
		
		ventana_principal.update_idletasks()

	button = Button(frame_carga_centrado, text= "Descarga").pack()
	
def principal():

	global vcmd
	global vcmd2
	global frame_botones
	global frame_botones2

	ventana_principal.state("zoomed")
	vcmd=(ventana_principal.register(validate_entry_numeros),"%S")
	vcmd2=(ventana_principal.register(validate_entry_letras_espacios),"%S")

	frame_botones= ttk.Frame(ventana_principal,style='navegacion.TFrame')
	frame_botones.pack(side=LEFT,fill=Y)
	frame_botones2= ttk.Frame(ventana_principal,style='navegacion.TFrame')
	frame_botones2.pack(side=RIGHT,fill=Y)
	frame_contenido = ttk.Frame(ventana_principal,style='principal.TFrame')
	frame_contenido.pack(side=LEFT,fill=BOTH,expand=1)

	inicio(frame_contenido)

	def verInicio():
		global imagen_pil_inicio
		borrarFrames()
		if 'frame_inicio' not in globals():
			inicio(frame_contenido)
		else:
			frame_inicio.pack(fill=BOTH,expand=1)
	def verInventario():
		global imagen_pil_stock
		borrarFrames()
		if 'frame_inventario' not in globals():
			inventario(frame_contenido)
		else:
			frame_inventario.pack(fill=BOTH,expand=1)

	imagen_pil_stock= Image.open("iconos/btnStock.png")
	imagen_resize_inventarios = imagen_pil_stock.resize((50,50))
	imagen_tk_inventarios= ImageTk.PhotoImage(imagen_resize_inventarios)

	boton_inventario = ttk.Button(frame_botones,text='Inventario',style='botonNavegacion.TButton',command=verInventario)
	boton_inventario.config(image=imagen_tk_inventarios,compound=LEFT)
	boton_inventario.image = imagen_tk_inventarios
	boton_inventario.pack(pady=20)

	def verClientes():
		global imagen_pil_clientes
		borrarFrames()
		if 'frame_clientes' not in globals():
			clientes(frame_contenido)
		else:
			frame_clientes.pack(fill=BOTH,expand=1)

	imagen_pil_clientes= Image.open("iconos/btnClientes.png")
	imagen_resize_clientes = imagen_pil_clientes.resize((50,50))
	imagen_tk_clientes= ImageTk.PhotoImage(imagen_resize_clientes)

	boton_clientes = ttk.Button(frame_botones,text='Clientes',style='botonNavegacion.TButton',command=verClientes)
	boton_clientes.config(image=imagen_tk_clientes,compound=LEFT)
	boton_clientes.image = imagen_tk_clientes
	boton_clientes.pack(pady=20)

	def verProveedores():
		global imagen_pil_proveedores
		borrarFrames()
		if 'frame_proveedores' not in globals():
			proveedores(frame_contenido)
		else:
			frame_proveedores.pack(fill=BOTH,expand=1)

	imagen_pil_proveedores= Image.open("iconos/btnProveedores.png")
	imagen_resize_proveedores = imagen_pil_proveedores.resize((50,50))
	imagen_tk_proveedores= ImageTk.PhotoImage(imagen_resize_proveedores)

	boton_proveedores = ttk.Button(frame_botones,text='Proveedores',style='botonNavegacion.TButton',command=verProveedores)
	boton_proveedores.config(image=imagen_tk_proveedores,compound=LEFT)
	boton_proveedores.image = imagen_tk_proveedores
	boton_proveedores.pack(pady=20)

	def verCompras():
		global imagen_pil_compras
		borrarFrames()
		if 'frame_compras' not in globals():
			compras(frame_contenido)
		else:
			frame_compras.pack(fill=BOTH,expand=1)

	imagen_pil_compras= Image.open("iconos/btnCompras.png")
	imagen_resize_compras = imagen_pil_compras.resize((50,50))
	imagen_tk_compras= ImageTk.PhotoImage(imagen_resize_compras)

	boton_compras = ttk.Button(frame_botones,text='Compras',style='botonNavegacion.TButton',command=verCompras)
	boton_compras.config(image=imagen_tk_compras,compound=LEFT)
	boton_compras.image = imagen_tk_compras
	boton_compras.pack(pady=20)

	def verVentas():
		global imagen_pil_ventas
		borrarFrames()
		if 'frame_ventas' not in globals():
			ventas(frame_contenido)
		else:
			frame_ventas.pack(fill=BOTH,expand=1)

	imagen_pil_ventas= Image.open("iconos/btnVentas.png")
	imagen_resize_ventas = imagen_pil_ventas.resize((50,50))
	imagen_tk_ventas= ImageTk.PhotoImage(imagen_resize_ventas)
		
	boton_ventas = ttk.Button(frame_botones,text='Ventas',style='botonNavegacion.TButton',command=verVentas)
	boton_ventas.config(image=imagen_tk_ventas,compound=LEFT)
	boton_ventas.image = imagen_tk_ventas
	boton_ventas.pack(pady=20)
	
	def verReportes():
		global imagen_pil_reportes
		borrarFrames()
		if 'frame_reportes' not in globals():
			reportes(frame_contenido)
		else:
			frame_reportes.pack(fill=BOTH,expand=1)

	imagen_pil_reportes= Image.open("iconos/btnReportes.png")
	imagen_resize_reportes = imagen_pil_reportes.resize((50,50))
	imagen_tk_reportes= ImageTk.PhotoImage(imagen_resize_reportes)

	boton_reportes = ttk.Button(frame_botones2,text='Reportes',style='botonNavegacion.TButton',command=verReportes)
	boton_reportes.config(image=imagen_tk_reportes,compound=LEFT)
	boton_reportes.image = imagen_tk_reportes
	boton_reportes.pack(pady=20)

	def verUsuarios():
		global imagen_pil_usuarios
		borrarFrames()
		if 'frame_usuarios' not in globals():
			usuarios(frame_contenido)
		else:
			frame_usuarios.pack(fill=BOTH,expand=1)
	
	imagen_pil_usuarios= Image.open("iconos/btnUsuarios.png")
	imagen_resize_usuarios = imagen_pil_usuarios.resize((50,50))
	imagen_tk_usuarios= ImageTk.PhotoImage(imagen_resize_usuarios)

	boton_usuarios = ttk.Button(frame_botones2,text='Usuarios',style='botonNavegacion.TButton',command=verUsuarios)
	boton_usuarios.config(image=imagen_tk_usuarios,compound=LEFT)
	boton_usuarios.image = imagen_tk_usuarios
	boton_usuarios.pack(pady=20)

	def verGastos():
		borrarFrames()
		global imagen_pil_gastos
		if 'frame_gastos' not in globals():
			gastos(frame_contenido)
		else:
			frame_gastos.pack(fill=BOTH,expand=1)
	
	imagen_pil_gastos= Image.open("iconos/btnGastos.png")
	imagen_resize_gastos = imagen_pil_gastos.resize((50,50))
	imagen_tk_gastos= ImageTk.PhotoImage(imagen_resize_gastos)

	boton_gastos = ttk.Button(frame_botones2,text='Gastos',style='botonNavegacion.TButton',command=verGastos)
	boton_gastos.config(image=imagen_tk_gastos,compound=LEFT)
	boton_gastos.image = imagen_tk_gastos
	boton_gastos.pack(pady=20)

	def verEmpleados():
		global imagen_pil_empleados
		borrarFrames()
		if 'frame_empleados' not in globals():
			empleados(frame_contenido)
		else:
			frame_empleados.pack(fill=BOTH,expand=1)

	imagen_pil_empleados= Image.open("iconos/btnEmpleados.png")
	imagen_resize_empleados = imagen_pil_empleados.resize((50,50))
	imagen_tk_empleados= ImageTk.PhotoImage(imagen_resize_empleados)

	boton_empleados = ttk.Button(frame_botones2,text='Empleados',style='botonNavegacion.TButton',command=verEmpleados)
	boton_empleados.config(image=imagen_tk_empleados,compound=LEFT)
	boton_empleados.image = imagen_tk_empleados
	boton_empleados.pack(pady=20)

	def verAcerca():
		global imagen_pil_acerca
		borrarFrames()
		if 'frame_acerca' not in globals():
			acerca(frame_contenido)
		else:
			frame_acerca.pack(fill=BOTH,expand=1)

	imagen_pil_acerca= Image.open("iconos/btnAcerca.png")
	imagen_resize_acerca = imagen_pil_acerca.resize((50,50))
	imagen_tk_acerca= ImageTk.PhotoImage(imagen_resize_acerca)

	boton_acerca = ttk.Button(frame_botones2,text='Acerca',style='botonNavegacion.TButton',command=verAcerca)
	boton_acerca.config(image=imagen_tk_acerca,compound=LEFT)
	boton_acerca.image = imagen_tk_acerca
	boton_acerca.pack(pady=20)

	def cierreSesion():
		ventana_principal.destroy()

	imagen_pil_cierre= Image.open("iconos/btnCierre.png")
	imagen_resize_cierre = imagen_pil_cierre.resize((50,50))
	imagen_tk_cierre= ImageTk.PhotoImage(imagen_resize_cierre)

	Boton_cierre = ttk.Button(frame_botones2,text='Cierre Sesion',style='botonNavegacion.TButton',command=cierreSesion)
	Boton_cierre.config(image=imagen_tk_cierre,compound=LEFT)
	Boton_cierre.image = imagen_tk_cierre
	Boton_cierre.pack(pady=20)

def principal_empleado():

	global vcmd
	global vcmd2
	global frame_botones
	global frame_botones2

	ventana_principal.state("zoomed")
	vcmd=(ventana_principal.register(validate_entry_numeros),"%S")
	vcmd2=(ventana_principal.register(validate_entry_letras_espacios),"%S")
	frame_botones= ttk.Frame(ventana_principal,style='navegacion.TFrame')
	frame_botones.pack(side=LEFT,fill=Y)
	frame_botones2= ttk.Frame(ventana_principal,style='navegacion.TFrame')
	frame_botones2.pack(side=RIGHT,fill=Y)
	frame_contenido = ttk.Frame(ventana_principal,style='principal.TFrame')
	frame_contenido.pack(side=LEFT,fill=BOTH,expand=1)

	inicio(frame_contenido)

	def verInicio():
		global imagen_pil_inicio
		borrarFrames()
		if 'frame_inicio' not in globals():
			inicio(frame_contenido)
		else:
			frame_inicio.pack(fill=BOTH,expand=1)

	def verInventario():
		global imagen_pil_stock
		borrarFrames()
		if 'frame_inventario' not in globals():
			inventario(frame_contenido)
		else:
			frame_inventario.pack(fill=BOTH,expand=1)

	imagen_pil_stock= Image.open("iconos/btnStock.png")
	imagen_resize_inventarios = imagen_pil_stock.resize((50,50))
	imagen_tk_inventarios= ImageTk.PhotoImage(imagen_resize_inventarios)

	boton_inventario = ttk.Button(frame_botones,text='Inventario',style='botonNavegacion.TButton',command=verInventario)
	boton_inventario.config(image=imagen_tk_inventarios,compound=LEFT)
	boton_inventario.image = imagen_tk_inventarios
	boton_inventario.pack(pady=20)

	def verClientes():
		global imagen_pil_clientes
		borrarFrames()
		if 'frame_clientes' not in globals():
			clientes(frame_contenido)
		else:
			frame_clientes.pack(fill=BOTH,expand=1)

	imagen_pil_clientes= Image.open("iconos/btnClientes.png")
	imagen_resize_clientes = imagen_pil_clientes.resize((50,50))
	imagen_tk_clientes= ImageTk.PhotoImage(imagen_resize_clientes)

	boton_clientes = ttk.Button(frame_botones,text='Clientes',style='botonNavegacion.TButton',command=verClientes)
	boton_clientes.config(image=imagen_tk_clientes,compound=LEFT)
	boton_clientes.image = imagen_tk_clientes
	boton_clientes.pack(pady=20)

	def verProveedores():
		global imagen_pil_proveedores
		borrarFrames()
		if 'frame_proveedores' not in globals():
			proveedores(frame_contenido)
		else:
			frame_proveedores.pack(fill=BOTH,expand=1)

	imagen_pil_proveedores= Image.open("iconos/btnProveedores.png")
	imagen_resize_proveedores = imagen_pil_proveedores.resize((50,50))
	imagen_tk_proveedores= ImageTk.PhotoImage(imagen_resize_proveedores)

	boton_proveedores = ttk.Button(frame_botones,text='Proveedores',style='botonNavegacion.TButton',command=verProveedores)
	boton_proveedores.config(image=imagen_tk_proveedores,compound=LEFT)
	boton_proveedores.image = imagen_tk_proveedores
	boton_proveedores.pack(pady=20)

	def verVentas():
		global imagen_pil_ventas
		borrarFrames()
		if 'frame_ventas' not in globals():
			ventas(frame_contenido)
		else:
			frame_ventas.pack(fill=BOTH,expand=1)

	imagen_pil_ventas= Image.open("iconos/btnVentas.png")
	imagen_resize_ventas = imagen_pil_ventas.resize((50,50))
	imagen_tk_ventas= ImageTk.PhotoImage(imagen_resize_ventas)
		
	boton_ventas = ttk.Button(frame_botones,text='Ventas',style='botonNavegacion.TButton',command=verVentas)
	boton_ventas.config(image=imagen_tk_ventas,compound=LEFT)
	boton_ventas.image = imagen_tk_ventas
	boton_ventas.pack(pady=20)

	def verAcerca():
		global imagen_pil_acerca
		borrarFrames()
		if 'frame_acerca' not in globals():
			acerca(frame_contenido)
		else:
			frame_acerca.pack(fill=BOTH,expand=1)

	imagen_pil_acerca= Image.open("iconos/btnAcerca.png")
	imagen_resize_acerca = imagen_pil_acerca.resize((50,50))
	imagen_tk_acerca= ImageTk.PhotoImage(imagen_resize_acerca)

	boton_acerca = ttk.Button(frame_botones,text='Acerca',style='botonNavegacion.TButton',command=verAcerca)
	boton_acerca.config(image=imagen_tk_acerca,compound=LEFT)
	boton_acerca.image = imagen_tk_acerca
	boton_acerca.pack(pady=20)

	def cierreSesion():
		ventana_principal.destroy()

	imagen_pil_cierre= Image.open("iconos/btnCierre.png")
	imagen_resize_cierre = imagen_pil_cierre.resize((50,50))
	imagen_tk_cierre= ImageTk.PhotoImage(imagen_resize_cierre)

	Boton_cierre = ttk.Button(frame_botones,text='Cierre Sesion',style='botonNavegacion.TButton',command=cierreSesion)
	Boton_cierre.config(image=imagen_tk_cierre,compound=LEFT)
	Boton_cierre.image = imagen_tk_cierre
	Boton_cierre.pack(pady=20)

def borrarFrames():
	if 'frame_inicio' in globals():
		frame_inicio.pack_forget()
	if 'frame_clientes' in globals():
		frame_clientes.pack_forget()
	if 'frame_proveedores' in globals():
		frame_proveedores.pack_forget()
	if 'frame_compras' in globals():
		frame_compras.pack_forget()
	if 'frame_ventas' in globals():
		frame_ventas.pack_forget()
	if 'frame_inventario' in globals():
		frame_inventario.pack_forget()
	if 'frame_reportes' in globals():
		frame_reportes.pack_forget()
	if 'frame_usuarios' in globals():
		frame_usuarios.pack_forget()
	if 'frame_gastos' in globals():
		frame_gastos.pack_forget()
	if 'frame_acerca' in globals():
		frame_acerca.pack_forget()
	if "frame_empleados" in globals():
		frame_empleados.pack_forget()
	frame_botones.pack_forget()
	frame_botones2.pack_forget()	

def inicio(frame_contenido):
	global frame_inicio
	global imagenFrameInicio
	global imagenDeLogoPrincipal
	global imagenLatido

	frame_inicio = ttk.Frame(frame_contenido,style='fondo.TFrame')
	frame_inicio.pack(fill=BOTH,expand=1)

	frame_contenido_inicio=ttk.Frame(frame_inicio,style="fondo.TFrame")
	frame_contenido_inicio.pack(fill=Y,side=LEFT,padx=70,pady=20)

	frame_contenido_calendario=Frame(frame_inicio,bg="black")
	frame_contenido_calendario.pack(fill=Y,side=RIGHT,ipadx=100,padx=50,pady=50)
	
	cal = Calendar(frame_contenido_calendario,selectmode = "day", year =2024,month =7,day=22,bg="black")
	cal.pack(ipadx=30,ipady=30)

	imagenLatido=PhotoImage(file="latido.png")
	labelLatido= Label(frame_contenido_calendario,image=imagenLatido)
	labelLatido.pack(pady=60)

	titulo_programa = ttk.Label(frame_contenido_inicio,text=nombrePrograma,anchor="c",justify=RIGHT,style="programa.TLabel")
	titulo_programa.pack(pady=50)

	imagenDeLogoPrincipal=PhotoImage(file="imagenLogo.png")
	label_De_Logo_Principal = Label(frame_contenido_inicio,image=imagenDeLogoPrincipal)
	label_De_Logo_Principal.pack(pady=20)

	label_direccion = ttk.Label(frame_contenido_inicio,text="Bienvenido/a a Sistema de Ventas",anchor="c",justify=RIGHT,style='subTitulo.TLabel')
	label_direccion.pack(pady=20)

	label_contacto = ttk.Label(frame_contenido_inicio,text="Insumos médicos",anchor="c",justify=RIGHT,style='subTitulo.TLabel')
	label_contacto.pack(pady=10)

	label_mail = ttk.Label(frame_contenido_inicio,text="Clínicas-Hospitales-Ortopedias-Uso dosmético",anchor="c",justify=RIGHT,style='subTitulo.TLabel')
	label_mail.pack(pady=20)

def clientes(frame_contenido):

	#Variable Global
	global frame_clientes

	#Frame
	frame_clientes = ttk.Frame(frame_contenido,style='fondo.TFrame')
	frame_clientes.pack(fill=BOTH,expand=1)

	frame_contenido_clientes = ttk.Frame(frame_clientes,style="navegacion.TFrame")
	frame_contenido_clientes.pack(side=LEFT,fill=Y,ipadx=50)

	frame_botones_cliente= ttk.Frame(frame_clientes,style="navegacion.TFrame")
	frame_botones_cliente.pack(side=RIGHT,fill=Y)

	#Creación de listbox
	
	
	listbox_clientes = Listbox(frame_clientes)
	listbox_clientes.place(x=480,y=100,width=500,height=500)
	scrol_y_c = ttk.Scrollbar(listbox_clientes,orient=VERTICAL)
	scrol_y_c.pack(side=RIGHT,fill=Y)
	scrol_x_c = ttk.Scrollbar(listbox_clientes,orient=HORIZONTAL)
	scrol_x_c.pack(side=BOTTOM,fill=X)

	
	#Evento mostrar en listbox
	def mostrarClientes(evento):
		indiceClientes=listbox_clientes.curselection()[0]
		mensajeClientes=listbox_clientes.get(indiceClientes)
		messagebox.showinfo("LifeHealth",mensajeClientes)
	listbox_clientes.bind("<<ListboxSelect>>",mostrarClientes)

	#Label y Entry CRUD
	label_clientes = LabelFrame(frame_contenido_clientes,bg="SkyBlue4",text="Datos del cliente",font= "Georgia 20 bold")
	label_clientes.pack(anchor=W,padx=10,pady=20)

	label_buscar_clientes =ttk.Label(label_clientes,text="Buscar Cliente por ID",style="labelNavegacion.TLabel")
	label_buscar_clientes.pack(anchor=NW,pady=10,padx=20)
	entry_buscar_clientes = ttk.Entry(label_clientes,style="entradasNavegacion.TLabel",width=35)
	entry_buscar_clientes.pack(anchor=NW,padx=20)	

	label_id_clientes = ttk.Label(label_clientes,text="ID cliente",style="labelNavegacion.TLabel")
	label_id_clientes.pack(anchor=NW,pady=10,padx=20)
	entry_id_clientes = ttk.Entry(label_clientes,style="entradasNavegacion.TLabel",width=35)
	entry_id_clientes.pack(anchor=NW,padx=20)

	entry_id_clientes.config(state="readonly")

	label_dni_clientes = ttk.Label(label_clientes,text="DNI",style="labelNavegacion.TLabel")
	label_dni_clientes.pack(anchor=NW,pady=10,padx=20)
	entry_dni_clientes = ttk.Entry(label_clientes,style="entradasNavegacion.TLabel",width=35,validate= "key",validatecommand=vcmd)
	entry_dni_clientes.pack(anchor=NW,padx=20)

	label_nombre_clientes = ttk.Label(label_clientes,text="Nombre",style="labelNavegacion.TLabel")
	label_nombre_clientes.pack(anchor=NW,pady=10,padx=20)
	entry_nombre_clientes = ttk.Entry(label_clientes,style="entradasNavegacion.TLabel",width=35)
	entry_nombre_clientes.pack(anchor=NW,padx=20)

	label_tel_clientes = ttk.Label(label_clientes,text="Telefono",style="labelNavegacion.TLabel")
	label_tel_clientes.pack(anchor=NW,pady=10,padx=20)
	entry_tel_clientes = ttk.Entry(label_clientes,style="entradasNavegacion.TLabel",width=35,validate= "key",validatecommand=vcmd)
	entry_tel_clientes.pack(anchor=NW,padx=20)

	label_cuit_clientes = ttk.Label(label_clientes,text="CUIT",style="labelNavegacion.TLabel")
	label_cuit_clientes.pack(anchor=NW,pady=10,padx=20)
	entry_cuit_clientes = ttk.Entry(label_clientes,style="entradasNavegacion.TLabel",width=35,validate= "key",validatecommand=vcmd)
	entry_cuit_clientes.pack(anchor=NW,padx=20)

	label_direccion_clientes = ttk.Label(label_clientes,text="Dirección",style="labelNavegacion.TLabel")
	label_direccion_clientes.pack(anchor=NW,pady=10,padx=20)
	entry_direccion_clientes = ttk.Entry(label_clientes,style="entradasNavegacion.TLabel",width=35)
	entry_direccion_clientes.pack(anchor=NW,padx=20)

	label_email_clientes = ttk.Label(label_clientes,text="E-MAIL",style="labelNavegacion.TLabel")
	label_email_clientes.pack(anchor=NW,pady=10,padx=20)
	entry_email_clientes = ttk.Entry(label_clientes,style="entradasNavegacion.TLabel",width=35)
	entry_email_clientes.pack(anchor=NW,padx=20)

	label_iva_clientes = ttk.Label(label_clientes,text="IVA",style="labelNavegacion.TLabel")
	label_iva_clientes.pack(anchor=NW,pady=10,padx=20)
	entry_iva_clientes = ttk.Entry(label_clientes,style="entradasNavegacion.TLabel",width=35)
	entry_iva_clientes.pack(anchor=NW,padx=20)

	#Buscar Cliente
	def buscarClientes():
		global datos
		buscarClientes=entry_buscar_clientes.get() 
		if(buscarClientes !=""):
			try:
				ver=True
				for letra in buscarClientes:
					if(not(letra.isdigit())):
						ver=False
						break
				if(ver):
					buscarClientes = (entry_buscar_clientes.get(),)
					tabla=conexion.cursor()
					tabla.execute("SELECT * FROM Clientes WHERE idClientes=?",buscarClientes)
					datos = tabla.fetchall()

					entry_id_clientes.config(state="normal")
					entry_id_clientes.delete(0,END)
					entry_dni_clientes.config(state="normal")
					entry_dni_clientes.delete(0,END)
					entry_nombre_clientes.delete(0,END)
					entry_tel_clientes.delete(0,END)
					entry_cuit_clientes.delete(0,END)
					entry_direccion_clientes.delete(0,END)
					entry_email_clientes.delete(0,END)
					entry_iva_clientes.delete(0,END)

					boton_modificar_clientes.config(state="normal")
					boton_eliminar_clientes.config(state="normal")
					if(len(datos)>0):
						boton_guardar_clientes.config(state="disabled")
						for dato in datos:
							idClientes=dato[0]
							dniClientes=dato[1]
							nombreClientes=dato[2]
							telClientes=dato[3]
							cuitClientes=dato[4]
							direccionClientes=dato[5]
							emailClientes=[6]
							ivaClientes=dato[7]

							entry_id_clientes.insert(END,idClientes)
							entry_dni_clientes.insert(END,dniClientes)
							entry_nombre_clientes.insert(END,nombreClientes)
							entry_tel_clientes.insert(END,telClientes)
							entry_cuit_clientes.insert(END,cuitClientes)
							entry_direccion_clientes.insert(END,direccionClientes)
							entry_email_clientes.insert(END,emailClientes)
							entry_iva_clientes.insert(END,ivaClientes)
					else:
						messagebox.showwarning("LifeHealth","No se encrontró cliente")
						entry_id_clientes.config(state="readonly")
				else:
					messagebox.showwarning(title="LifeHealth",message="Ingrese solo números")
			except ValueError:
				messagebox.showwarning(title="LifeHealth",message="Registro incorrecto")
		else:
			messagebox.showwarning(title="LifeHealth",message="Ingrese algo que buscar")		
	
	boton_buscar_clientes = ttk.Button(frame_botones_cliente,text="BUSCAR",style="botonNavegacion.TButton",command = buscarClientes)
	boton_buscar_clientes.pack(padx=20,pady=30)
	
	#Guardar Cliente
	def guardarClientes():
		try:
			boton_guardar_clientes.config(state="normal")
			dniClientes = entry_dni_clientes.get()
			nombreClientes = entry_nombre_clientes.get()
			telClientes = entry_tel_clientes.get()
			cuitClientes = entry_cuit_clientes.get()
			direccionClientes = entry_direccion_clientes.get()
			emailClientes = entry_email_clientes.get()
			ivaClientes = entry_iva_clientes.get()

			if(dniClientes != "" and nombreClientes != "" and telClientes != "" and cuitClientes  !="" and direccionClientes != "" and emailClientes != "" and ivaClientes !=""):
				datos = (dniClientes,nombreClientes,telClientes,cuitClientes,direccionClientes,emailClientes,ivaClientes)
				tabla = conexion.cursor()
				tabla.execute("INSERT INTO Clientes(dniClientes,nombreClientes,telClientes,cuitClientes,direccionClientes,emailClientes,ivaClientes)VALUES(?,?,?,?,?,?,?)",datos)
				conexion.commit()
				messagebox.showinfo("LifeHealth","Guardado con éxito")
				
				limpiarClientes()
				listarClientes()
				
			else:
				messagebox.showwarning("LifeHealth","Complete todos los campos")

		except ValueError   as e:
			messagebox.showerror("Error","Error datos de la base de datos, {e}")

	boton_guardar_clientes = ttk.Button(frame_botones_cliente,text="GUARDAR",style="botonNavegacion.TButton",command = guardarClientes)
	boton_guardar_clientes.pack(padx=20,pady=30)

	#Modificar Cliente
	def modificarClientes():
		boton_guardar_clientes.config(state="normal")

		idClientes = entry_id_clientes.get()
		dniClientes = entry_dni_clientes.get()
		nombreClientes = entry_nombre_clientes.get()
		telClientes = entry_tel_clientes.get()
		cuitClientes = entry_cuit_clientes.get()
		direccionClientes = entry_direccion_clientes.get()
		emailClientes = entry_email_clientes.get()
		ivaClientes = entry_iva_clientes.get()
		datos = (dniClientes,nombreClientes,telClientes,cuitClientes,direccionClientes,emailClientes,ivaClientes,idClientes)
		tabla=conexion.cursor()
		tabla.execute("UPDATE Clientes SET dniClientes=?,nombreClientes=?,telClientes=?,cuitClientes=?,direccionClientes=?,emailClientes=?,ivaClientes=? WHERE idClientes =?",datos)
		conexion.commit()
		messagebox.showinfo("LifeHealth","Modificado con éxito")
		limpiarClientes()
		listarClientes()
		
	boton_modificar_clientes = ttk.Button(frame_botones_cliente,text="MODIFICAR",style="botonNavegacion.TButton",command = modificarClientes)
	boton_modificar_clientes.pack(padx=20,pady=30)
	boton_modificar_clientes.config(state="disabled")

	#Eliminar Cliente
	def eliminarClientes():
		boton_guardar_clientes.config(state="normal")
		idClientes = entry_id_clientes.get()
		datos = (idClientes,)
		tabla=conexion.cursor()
		tabla.execute("DELETE FROM Clientes WHERE idClientes =?",datos)
		conexion.commit()
		messagebox.showinfo("LifeHealth","Eliminado con éxito")	
		limpiarClientes()
		listarClientes()

	boton_eliminar_clientes = ttk.Button(frame_botones_cliente,text="ELIMINAR",style="botonNavegacion.TButton",command = eliminarClientes)
	boton_eliminar_clientes.pack(padx=20,pady=30)
	boton_eliminar_clientes.config(state="disabled")

	#Limpiar Cliente
	def limpiarClientes():
		boton_guardar_clientes.config(state="normal")
		entry_buscar_clientes.delete(0,END)
		entry_id_clientes.config(state="normal")
		entry_id_clientes.delete(0,END)
		entry_id_clientes.config(state="readonly")
		entry_dni_clientes.delete(0,END)
		entry_nombre_clientes.delete(0,END)
		entry_tel_clientes.delete(0,END)
		entry_cuit_clientes.delete(0,END)
		entry_direccion_clientes.delete(0,END)
		entry_email_clientes.delete(0,END)
		entry_iva_clientes.delete(0,END)

		boton_modificar_clientes.config(state="disable")
		boton_eliminar_clientes.config(state="disable")

	boton_limpiar_clientes = ttk.Button(frame_botones_cliente,text="LIMPIAR",style="botonNavegacion.TButton",command = limpiarClientes)
	boton_limpiar_clientes.pack(padx=20,pady=30)

	def listarClientes():

		tabla = conexion.cursor()
		tabla.execute("SELECT * FROM Clientes")
		listado = tabla.fetchall()
		listbox_clientes.delete(0,END)

		for elemento in listado:
			informacionCliente = "ID:"+"  "+str(elemento[0])+"  "+"DNI:"+"  "+str(elemento[1])+"  "+"Nombre:"+"  "+elemento[2]   
			listbox_clientes.insert(END,informacionCliente)
	
	boton_listar_clientes = ttk.Button(frame_botones_cliente,text="LISTAR",style="botonNavegacion.TButton",command = listarClientes())
	boton_listar_clientes.pack(padx=20,pady=30)	

	def volverPrincipalCliente():
		global imagen_pil_volver_cliente
		frame_clientes.pack_forget()
		principal()


	imagen_pil_volver_cliente= Image.open("iconos/btnVolver.png")
	imagen_resize_volver_cliente = imagen_pil_volver_cliente.resize((30,30))
	imagen_tk_volver_cliente= ImageTk.PhotoImage(imagen_resize_volver_cliente)

	boton_volver_cliente = ttk.Button(frame_botones_cliente,text="VOLVER",style="botonNavegacion.TButton",command = volverPrincipalCliente)
	boton_volver_cliente.config(image=imagen_tk_volver_cliente,compound=LEFT)
	boton_volver_cliente.image = imagen_tk_volver_cliente 
	boton_volver_cliente.pack(side=BOTTOM,padx=20,pady=30)

def proveedores(frame_contenido):
	global frame_proveedores
	global combo
	frame_proveedores = ttk.Frame(frame_contenido,style='fondo.TFrame')
	frame_proveedores.pack(fill=BOTH,expand=1)

	frame_buscador_proveedores=ttk.Frame(frame_proveedores,style="fondo.TFrame")
	frame_buscador_proveedores.pack(fill=X,pady=40)

	frame_datos_proveedores=ttk.Frame(frame_buscador_proveedores,style="principal.TFrame")
	frame_datos_proveedores.pack(fill=X,expand=1,padx=30)

	frame_buscado_proveedores=ttk.Frame(frame_proveedores,style="navegacion.TFrame")
	frame_buscado_proveedores.pack(ipadx=150,ipady=50,padx=40,pady=40)
	
	label_busqueda_proveedores=ttk.Label(frame_datos_proveedores,text="Buscar proveedor por nombre",style="labelNavegacion.TLabel")
	label_busqueda_proveedores.pack(side=LEFT,padx=20,pady=20)
	entry_busqueda_proveedores=ttk.Entry(frame_datos_proveedores,style="entradasNavegacion2.TLabel",width=35)
	entry_busqueda_proveedores.pack(side=LEFT,padx=10,pady=20)

	combo = ttk.Combobox(frame_datos_proveedores)

	label_datos_proveedor=ttk.Label(frame_buscado_proveedores,text="Datos proveedor",style="subTitulo.TLabel")
	label_datos_proveedor.grid(row=1,column=1,pady=20,padx=5)

	label_numero_proveedor=ttk.Label(frame_buscado_proveedores,text="N°",style="labelNavegacion.TLabel")
	label_numero_proveedor.grid(row=1,column=2,pady=10)
	entry_numero_proveedor=ttk.Entry(frame_buscado_proveedores,style="entradasNavegacion.TLabel",width=35,validate= "key",validatecommand=vcmd)
	entry_numero_proveedor.grid(row=1,column=3,ipady=5,ipadx=5,pady=10)
	entry_numero_proveedor.config(state="readonly")

	label_cuit_proveedor=ttk.Label(frame_buscado_proveedores,text="CUIT",style="labelNavegacion.TLabel")
	label_cuit_proveedor.grid(row=2,column=1,pady=10,padx=5)
	entry_cuit_proveedor=ttk.Entry(frame_buscado_proveedores,width=35,style="entradasNavegacion.TLabel",validate= "key",validatecommand=vcmd)
	entry_cuit_proveedor.grid(row=2,column=2,ipady=5,ipadx=5,pady=10,padx=5)

	label_nombre_proveedor=ttk.Label(frame_buscado_proveedores,text="Razón social",style="labelNavegacion.TLabel")
	label_nombre_proveedor.grid(row=3,column=1,pady=10,padx=5)
	entry_nombre_proveedor=ttk.Entry(frame_buscado_proveedores,width=35,style="entradasNavegacion.TLabel")
	entry_nombre_proveedor.grid(row=3,column=2,ipady=5,ipadx=5,pady=10,padx=5)

	label_categoria_proveedor=ttk.Label(frame_buscado_proveedores,text="Categoria",style="labelNavegacion.TLabel")
	label_categoria_proveedor.grid(row=4,column=1,pady=10,padx=5)
	entry_categoria_proveedor=ttk.Entry(frame_buscado_proveedores,width=35,style="entradasNavegacion.TLabel")
	entry_categoria_proveedor.grid(row=4,column=2,ipady=5,ipadx=5,pady=10,padx=5)


	label_telefono_proveedor=ttk.Label(frame_buscado_proveedores,text="Teléfono contacto",style="labelNavegacion.TLabel")
	label_telefono_proveedor.grid(row=2,column=3,pady=10,padx=5)
	entry_numero_proveedor.config(state="disabled")
	entry_telefono_proveedor=ttk.Entry(frame_buscado_proveedores,width=35,style="entradasNavegacion.TLabel",validate= "key",validatecommand=vcmd)
	entry_telefono_proveedor.grid(row=2,column=4,ipady=5,ipadx=5,pady=10,padx=5)

	label_insumo_proveedor=ttk.Label(frame_buscado_proveedores,text="Insumos",style="labelNavegacion.TLabel")
	label_insumo_proveedor.grid(row=3,column=3,pady=10,padx=5)
	entry_insumo_proveedor=ttk.Entry(frame_buscado_proveedores,width=35,style="entradasNavegacion.TLabel")
	entry_insumo_proveedor.grid(row=3,column=4,ipady=5,ipadx=5,pady=10,padx=5)

	label_domicilio_proveedor=ttk.Label(frame_buscado_proveedores,text="Domicilio",style="labelNavegacion.TLabel")
	label_domicilio_proveedor.grid(row=4,column=3,pady=10,padx=5)
	entry_domicilio_proveedor=ttk.Entry(frame_buscado_proveedores,width=35,style="entradasNavegacion.TLabel")
	entry_domicilio_proveedor.grid(row=4,column=4,ipady=5,ipadx=5,pady=10,padx=5)

	label_cp_proveedor=ttk.Label(frame_buscado_proveedores,text="Código postal",style="labelNavegacion.TLabel")
	label_cp_proveedor.grid(row=2,column=5,pady=10,padx=5)
	entry_cp_proveedor=ttk.Entry(frame_buscado_proveedores,width=35,style="entradasNavegacion.TLabel",validate= "key",validatecommand=vcmd)
	entry_cp_proveedor.grid(row=2,column=6,ipady=5,ipadx=5,pady=10,padx=5)

	label_mail_proveedor=ttk.Label(frame_buscado_proveedores,text="E-mail",style="labelNavegacion.TLabel")
	label_mail_proveedor.grid(row=3,column=5,pady=10,padx=5)
	entry_mail_proveedor=ttk.Entry(frame_buscado_proveedores,width=35,style="entradasNavegacion.TLabel")
	entry_mail_proveedor.grid(row=3,column=6,ipady=5,ipadx=5,pady=10,padx=5)

	label_iva_proveedor=ttk.Label(frame_buscado_proveedores,text="IVA",style="labelNavegacion.TLabel")
	label_iva_proveedor.grid(row=4,column=5,pady=10,padx=5)
	entry_iva_proveedor=ttk.Entry(frame_buscado_proveedores,width=35,style="entradasNavegacion.TLabel")
	entry_iva_proveedor.grid(row=4,column=6,ipady=5,ipadx=5,pady=10,padx=5)


	def seleccionarComboProveedor(evento):
		frame_buscado_proveedores.pack()           
		indiceProveedor=combo.current()
		proveedor=datos[indiceProveedor]

		entry_numero_proveedor.config(state="normal")

		entry_numero_proveedor.delete(0,END)
		entry_cuit_proveedor.delete(0,END)
		entry_nombre_proveedor.delete(0,END)
		entry_categoria_proveedor.delete(0,END)
		entry_telefono_proveedor.delete(0,END)
		entry_insumo_proveedor.delete(0,END)
		entry_domicilio_proveedor.delete(0,END)
		entry_cp_proveedor.delete(0,END)
		entry_mail_proveedor.delete(0,END)
		entry_iva_proveedor.delete(0,END)

		entry_numero_proveedor.insert(END,proveedor[0])
		entry_cuit_proveedor.insert(END,proveedor[1])
		entry_nombre_proveedor.insert(END,proveedor[2])
		entry_categoria_proveedor.insert(END,proveedor[3])
		entry_telefono_proveedor.insert(END,proveedor[4])
		entry_insumo_proveedor.insert(END,proveedor[5])
		entry_domicilio_proveedor.insert(END,proveedor[6])
		entry_cp_proveedor.insert(END,proveedor[7])
		entry_mail_proveedor.insert(END,proveedor[8])
		entry_iva_proveedor.insert(END,proveedor[9])

	combo.bind("<<ComboboxSelected>>",seleccionarComboProveedor)

	def buscar_proveedor():
		boton_eliminar_proveedores.config(state="normal")
		boton_modificar_proveedores.config(state="normal")

		if(entry_busqueda_proveedores.get() == ""):
			messagebox.showwarning(title="LifeHealth",message="Ingrese algo que buscar")
		else:
			combo.pack_forget()
			busquedaProveedor=(entry_busqueda_proveedores.get(),)
			tabla=conexion.cursor()
			tabla.execute("SELECT * FROM Proveedores WHERE nombreProveedor=?",busquedaProveedor)             
			global datos
			datos=tabla.fetchall()
			if(len(datos)>0):
				combo.pack(side=TOP,fill=X,padx=10,pady=10)
				lista=[]
				for dato in datos:
					lista.append("Nombre de proveedor:"+" "+dato[2])
				combo.config(values=lista)
				combo.current(0)
				boton_guardar_proveedor.config(state="disabled")
			else:
				messagebox.showerror("LifeHealth","No se ha encontrado proveedor")
				limpiar_proveedores()
				combo.pack_forget()

	boton_buscar_proveedor=ttk.Button(frame_datos_proveedores,text="Buscar",style="botonNavegacion.TButton",command=buscar_proveedor)
	boton_buscar_proveedor.pack(side=LEFT,padx=60)

	def modificar_proveedores():

		nProveedor = entry_numero_proveedor.get()
		cuitProveedor = entry_cuit_proveedor.get()
		nombreProveedor = entry_nombre_proveedor.get()
		categoriaProveedor = entry_categoria_proveedor.get()
		telProveedor = entry_telefono_proveedor.get()
		insumosProveedor = entry_insumo_proveedor.get()
		domicilioProveedor = entry_domicilio_proveedor.get()
		cpProveedor = entry_cp_proveedor.get()
		mailProveedor = entry_mail_proveedor.get()
		ivaProveedor = entry_iva_proveedor.get()

		datos = (cuitProveedor,nombreProveedor,
			    categoriaProveedor,telProveedor,
			    insumosProveedor,domicilioProveedor,
			    cpProveedor,mailProveedor,
			    ivaProveedor,nProveedor)

		tabla=conexion.cursor()
		tabla.execute("UPDATE Proveedores SET cuitProveedor=?,nombreProveedor=?,categoriaProveedor =?,telProveedor=?,insumosProveedor=?,domicilioProveedor=?,cpProveedor=?,mailProveedor=?,ivaProveedor=? WHERE nProveedor =?",datos)
		conexion.commit()
		messagebox.showinfo("LifeHealth","Modificado con éxito")
		combo.pack_forget()
		limpiar_proveedores()
		boton_guardar_proveedor.config(state="normal")

	boton_modificar_proveedores=ttk.Button(frame_proveedores,text="MODIFICAR",style="botonNavegacion.TButton",command=modificar_proveedores)                                   
	boton_modificar_proveedores.pack(side=LEFT,padx=20,pady=20)

	def guardar_proveedores():
		cuitProveedor = entry_cuit_proveedor.get()
		nombreProveedor = entry_nombre_proveedor.get()
		categoriaProveedor = entry_categoria_proveedor.get()
		telProveedor = entry_telefono_proveedor.get()
		insumosProveedor = entry_insumo_proveedor.get()
		domicilioProveedor = entry_domicilio_proveedor.get()
		cpProveedor = entry_cp_proveedor.get()
		mailProveedor = entry_mail_proveedor.get()
		ivaProveedor = entry_iva_proveedor.get()

		if(cuitProveedor != "" and nombreProveedor != "" and categoriaProveedor != "" and telProveedor != "" and 
			insumosProveedor != "" and domicilioProveedor != "" and cpProveedor !=""and mailProveedor!= ""and ivaProveedor!=""):
			boton_modificar_proveedores.config(state="disable")

			datos = (cuitProveedor,nombreProveedor,categoriaProveedor,telProveedor,insumosProveedor,
				      domicilioProveedor,cpProveedor,mailProveedor,ivaProveedor)

			tabla = conexion.cursor()
			tabla.execute("INSERT INTO Proveedores(cuitProveedor,nombreProveedor,categoriaProveedor,telProveedor,insumosProveedor,domicilioProveedor,cpProveedor,mailProveedor,ivaProveedor)VALUES(?,?,?,?,?,?,?,?,?)",datos)
			conexion.commit()
			messagebox.showinfo("LifeHealth","Guardado con éxito")
			limpiar_proveedores()
			boton_modificar_proveedores.config(state="normal")
		else:
			messagebox.showwarning("LifeHealth","Complete todos los campos")
	boton_guardar_proveedor = ttk.Button(frame_proveedores,text="GUARDAR",style="botonNavegacion.TButton",command = guardar_proveedores)
	boton_guardar_proveedor.pack(side=LEFT,padx=20,pady=20)

	def eliminar_proveedores():
		boton_guardar_proveedor.config(state="normal")
		nProveedor = entry_numero_proveedor.get()
		datos = (nProveedor,)
		tabla=conexion.cursor()
		tabla.execute("DELETE FROM Proveedores WHERE nProveedor =?",datos)
		conexion.commit()
		messagebox.showinfo("LifeHealth","Eliminado con éxito")
		combo.pack_forget()
		limpiar_proveedores()
	boton_eliminar_proveedores = ttk.Button(frame_proveedores,text="ELIMINAR",style="botonNavegacion.TButton",command = eliminar_proveedores)
	boton_eliminar_proveedores.pack(side=LEFT,padx=20,pady=20)
	boton_eliminar_proveedores.config(state="disabled")

	def limpiar_proveedores():
		entry_busqueda_proveedores.delete(0,END)
		entry_numero_proveedor.config(state="normal")
		entry_numero_proveedor.delete(0,END)
		entry_numero_proveedor.config(state="readonly")
		entry_cuit_proveedor.delete(0,END)
		entry_nombre_proveedor.delete(0,END)
		entry_categoria_proveedor.delete(0,END)
		entry_telefono_proveedor.delete(0,END)
		entry_insumo_proveedor.delete(0,END)
		entry_domicilio_proveedor.delete(0,END)
		entry_cp_proveedor.delete(0,END)
		entry_mail_proveedor.delete(0,END)
		entry_iva_proveedor.delete(0,END)
		
		boton_guardar_proveedor.config(state="normal")
		boton_modificar_proveedores.config(state="disable")
		boton_eliminar_proveedores.config(state="disable")
		combo.pack_forget()
	boton_limpiar_proveedores = ttk.Button(frame_proveedores,text="LIMPIAR",style="botonNavegacion.TButton",command = limpiar_proveedores)
	boton_limpiar_proveedores.pack(side=LEFT,padx=20,pady=20)

	def volverPrincipalProveedor():
		global imagen_pil_volver_proveedor
		borrarFrames()
		principal()

	imagen_pil_volver_proveedor= Image.open("iconos/btnVolver.png")
	imagen_resize_volver_proveedor = imagen_pil_volver_proveedor.resize((30,30))
	imagen_tk_volver_proveedor= ImageTk.PhotoImage(imagen_resize_volver_proveedor)

	boton_volver_proveedor = ttk.Button(frame_proveedores,text="VOLVER",style="botonNavegacion.TButton",command = volverPrincipalProveedor)
	boton_volver_proveedor.config(image=imagen_tk_volver_proveedor,compound=LEFT)
	boton_volver_proveedor.image = imagen_tk_volver_proveedor
	boton_volver_proveedor.pack(side=LEFT,padx=20,pady=20)
	
def empleados(frame_contenido):
	global frame_empleados
	global combo
	frame_empleados = ttk.Frame(frame_contenido,style='fondo.TFrame')
	frame_empleados.pack(fill=BOTH,expand=1)

	frame_buscador_empleados=ttk.Frame(frame_empleados,style="fondo.TFrame")
	frame_buscador_empleados.pack(fill=X,pady=40)
	frame_datos_empleados=ttk.Frame(frame_buscador_empleados,style="principal.TFrame")
	frame_datos_empleados.pack(fill=X,expand=1,padx=30)
	frame_buscado_empleados=ttk.Frame(frame_empleados,style="navegacion.TFrame")
	frame_buscado_empleados.pack(ipadx=150,ipady=30,padx=30,pady=40)
	
	label_busqueda_empleados=ttk.Label(frame_datos_empleados,text="Buscar por nombre",style="labelNavegacion.TLabel")
	label_busqueda_empleados.pack(side=LEFT,padx=20,pady=20)
	entry_busqueda_empleados=ttk.Entry(frame_datos_empleados,style="entradasNavegacion2.TLabel",width=35)
	entry_busqueda_empleados.pack(side=LEFT,padx=10,pady=20)

	combo = ttk.Combobox(frame_datos_empleados)

	label_datos_empleados=ttk.Label(frame_buscado_empleados,text="Datos del empleado",style="subTitulo.TLabel")
	label_datos_empleados.grid(row=1,column=1,pady=35,padx=10,sticky=W)

	label_legajo_empleados=ttk.Label(frame_buscado_empleados,text="N Legajo°",style="labelNavegacion.TLabel",)
	label_legajo_empleados.grid(row=1,column=2,pady=35,padx=5)
	entry_legajo_empleados=ttk.Entry(frame_buscado_empleados,style="entradasNavegacion.TLabel",width=30)
	entry_legajo_empleados.grid(row=1,column=3,ipady=5,pady=35,padx=5,sticky=W)
	entry_legajo_empleados.config(state="readonly")

	label_cuit_empleados=ttk.Label(frame_buscado_empleados,text="CUIT",style="labelNavegacion.TLabel")
	label_cuit_empleados.grid(row=2,column=1,pady=5,padx=10,sticky=W)
	entry_cuit_empleados=ttk.Entry(frame_buscado_empleados,style="entradasNavegacion.TLabel",width=20,validate= "key",validatecommand=vcmd)
	entry_cuit_empleados.grid(row=2,column=2,ipady=5,ipadx=5,pady=5,padx=10,sticky=W)

	label_nombre_empleados=ttk.Label(frame_buscado_empleados,text="Nombre Completo",style="labelNavegacion.TLabel")
	label_nombre_empleados.grid(row=3,column=1,pady=5,padx=10,sticky=W)
	entry_nombre_empleados=ttk.Entry(frame_buscado_empleados,style="entradasNavegacion.TLabel",width=35)
	entry_nombre_empleados.grid(row=3,column=2,ipady=5,ipadx=5,pady=5,padx=10,sticky=W)

	label_dni_empleados=ttk.Label(frame_buscado_empleados,text="DNI",style="labelNavegacion.TLabel")
	label_dni_empleados.grid(row=4,column=1,pady=5,padx=10,sticky=W)
	entry_dni_empleados=ttk.Entry(frame_buscado_empleados,style="entradasNavegacion.TLabel",width=15,validate= "key",validatecommand=vcmd)
	entry_dni_empleados.grid(row=4,column=2,ipady=5,ipadx=5,pady=5,padx=10,sticky=W)

	label_civil_empleados=ttk.Label(frame_buscado_empleados,text="Estado Civil",style="labelNavegacion.TLabel")
	label_civil_empleados.grid(row=5,column=1,pady=5,padx=10,sticky=W)
	entry_civil_empleados=ttk.Entry(frame_buscado_empleados,style="entradasNavegacion.TLabel",width=15)
	entry_civil_empleados.grid(row=5,column=2,ipady=5,ipadx=5,pady=5,padx=10,sticky=W)

	label_hijos_empleados=ttk.Label(frame_buscado_empleados,text="Hijos:SI/NO",style="labelNavegacion.TLabel")
	label_hijos_empleados.grid(row=6,column=1,pady=5,padx=10,sticky=W)
	entry_hijos_empleados=ttk.Entry(frame_buscado_empleados,style="entradasNavegacion.TLabel",width=5)
	entry_hijos_empleados.grid(row=6,column=2,ipady=5,ipadx=5,pady=10,padx=10,sticky=W)

	label_nacionalidad_empleados=ttk.Label(frame_buscado_empleados,text="Nacionalidad",style="labelNavegacion.TLabel")
	label_nacionalidad_empleados.grid(row=2,column=4,pady=5,padx=5,sticky=W)
	entry_nacionalidad_empleados=ttk.Entry(frame_buscado_empleados,style="entradasNavegacion.TLabel",width=10)
	entry_nacionalidad_empleados.grid(row=2,column=5,ipady=5,ipadx=5,pady=5,padx=10,sticky=W)
	
	label_telefono_empleados=ttk.Label(frame_buscado_empleados,text="Teléfono contacto:Prefijo sin 0 y 15",style="labelNavegacion.TLabel")
	label_telefono_empleados.grid(row=3,column=4,pady=5,padx=10,sticky=W)
	entry_legajo_empleados.config(state="disabled")
	entry_tel_empleados=ttk.Entry(frame_buscado_empleados,style="entradasNavegacion.TLabel",width=15,validate= "key",validatecommand=vcmd)
	entry_tel_empleados.grid(row=3,column=5,ipady=5,ipadx=5,pady=5,padx=10,sticky=W)

	label_domicilio_empleados=ttk.Label(frame_buscado_empleados,text="Domicilio",style="labelNavegacion.TLabel")
	label_domicilio_empleados.grid(row=4,column=4,pady=5,padx=5,sticky=W)
	entry_domicilio_empleados=ttk.Entry(frame_buscado_empleados,style="entradasNavegacion.TLabel",width=35)
	entry_domicilio_empleados.grid(row=4,column=5,ipady=5,ipadx=5,pady=10,padx=5,sticky=W)

	label_mail_empleados=ttk.Label(frame_buscado_empleados,text="E-mail",style="labelNavegacion.TLabel")
	label_mail_empleados.grid(row=5,column=4,pady=5,padx=5,sticky=W)
	entry_mail_empleados=ttk.Entry(frame_buscado_empleados,style="entradasNavegacion.TLabel",width=30)
	entry_mail_empleados.grid(row=5,column=5,ipady=5,ipadx=5,pady=5,padx=5,sticky=W)

	label_contrato_empleados=ttk.Label(frame_buscado_empleados,text="Tipo de contratación",style="labelNavegacion.TLabel")
	label_contrato_empleados.grid(row=6,column=4,pady=5,padx=5,sticky=W)
	entry_contrato_empleados=ttk.Entry(frame_buscado_empleados,style="entradasNavegacion.TLabel",width=20)
	entry_contrato_empleados.grid(row=6,column=5,ipady=5,ipadx=5,pady=5,padx=5,sticky=W)



	def seleccionarComboEmpleado(evento):
		frame_buscado_empleados.pack()           
		indiceEmpleado=combo.current()
		empleado=datos[indiceEmpleado]

		entry_legajo_empleados.config(state="normal")

		entry_legajo_empleados.delete(0,END)
		entry_cuit_empleados.delete(0,END)
		entry_nombre_empleados.delete(0,END)
		entry_dni_empleados.delete(0,END)
		entry_civil_empleados.delete(0,END)
		entry_hijos_empleados.delete(0,END)
		entry_nacionalidad_empleados.delete(0,END)
		entry_tel_empleados.delete(0,END)
		entry_domicilio_empleados.delete(0,END)
		entry_mail_empleados.delete(0,END)
		entry_contrato_empleados.delete(0,END)
		entry_legajo_empleados.insert(END,empleado[0])
		entry_cuit_empleados.insert(END,empleado[1])
		entry_nombre_empleados.insert(END,empleado[2])
		entry_dni_empleados.insert(END,empleado[3])
		entry_civil_empleados.insert(END,empleado[4])
		entry_hijos_empleados.insert(END,empleado[5])
		entry_nacionalidad_empleados.insert(END,empleado[6])
		entry_tel_empleados.insert(END,empleado[7])
		entry_domicilio_empleados.insert(END,empleado[8])
		entry_mail_empleados.insert(END,empleado[9])
		entry_contrato_empleados.insert(END,empleado[10])

	combo.bind("<<ComboboxSelected>>",seleccionarComboEmpleado)

	def buscar_empleado():
		global combo
		boton_eliminar_empleado.config(state="normal")
		boton_modificar_empleado.config(state="normal")

		if(entry_busqueda_empleados.get() == ""):
			messagebox.showwarning(title="LifeHealth",message="Ingrese algo que buscar")
		else:
			combo.pack_forget()
			busquedaEmpleado=(entry_busqueda_empleados.get(),)
			tabla=conexion.cursor()
			tabla.execute("SELECT * FROM Empleados WHERE nombreEmpleados=?",busquedaEmpleado)             
			global datos
			datos=tabla.fetchall()
			if(len(datos)>0):
				combo.pack(side=TOP,fill=X,padx=10,pady=10)
				lista=[]
				for dato in datos:
					lista.append("Nombre de empleado:"+" "+dato[2])
				combo.config(values=lista)
				combo.current(0)

				boton_guardar_empleado.config(state="disabled")
			else:
				messagebox.showerror("LifeHealth","No se ha encontrado empleado")
				limpiar_empleados()
				combo.pack_forget()

	boton_buscar_empleado=ttk.Button(frame_datos_empleados,text="Buscar",style="botonNavegacion.TButton",command=buscar_empleado)
	boton_buscar_empleado.pack(side=LEFT,padx=60)

	def modificar_empleados():
		legajoEmpleados = entry_legajo_empleados.get()
		cuitEmpleados = entry_cuit_empleados.get()
		nombreEmpleados = entry_nombre_empleados.get()
		dniEmpleados = entry_dni_empleados.get()
		civilEmpleados = entry_civil_empleados.get()
		hijosEmpleados = entry_hijos_empleados.get()
		nacionalidadEmpleados = entry_nacionalidad_empleados.get()
		telEmpleados = entry_tel_empleados.get()
		domicilioEmpleados = entry_domicilio_empleados.get()
		mailEmpleados = entry_mail_empleados.get()
		contratoEmpleados = entry_contrato_empleados.get()

		datos = (cuitEmpleados,nombreEmpleados,
			    dniEmpleados,civilEmpleados,
			    hijosEmpleados,nacionalidadEmpleados,
			    telEmpleados,domicilioEmpleados,
			    mailEmpleados,contratoEmpleados,legajoEmpleados)

		tabla=conexion.cursor()
		tabla.execute("UPDATE Empleados SET cuitEmpleados=?,nombreEmpleados=?,dniEmpleados =?,civilEmpleados=?,hijosEmpleados=?,nacionalidadEmpleados=?,telEmpleados=?,domicilioEmpleados=?,mailEmpleados=?,contratoEmpleados=? WHERE legajoEmpleados =?",datos)
		conexion.commit()
		messagebox.showinfo("LifeHealth","Modificado con éxito")
		combo.pack_forget()
		limpiar_empleados()
		boton_guardar_empleado.config(state="normal")
		
	boton_modificar_empleado = ttk.Button(frame_empleados,text="MODIFICAR",style="botonNavegacion.TButton",command = modificar_empleados)
	boton_modificar_empleado.pack(side=LEFT,padx=20,pady=10)
	
		
	def guardar_empleados():
		cuitEmpleados = entry_cuit_empleados.get()
		nombreEmpleados = entry_nombre_empleados.get()
		dniEmpleados = entry_dni_empleados.get()
		civilEmpleados = entry_civil_empleados.get()
		hijosEmpleados = entry_hijos_empleados.get()
		nacionalidadEmpleados = entry_nacionalidad_empleados.get()
		telEmpleados = entry_tel_empleados.get()
		domicilioEmpleados = entry_domicilio_empleados.get()
		mailEmpleados = entry_mail_empleados.get()
		contratoEmpleados = entry_contrato_empleados.get()


		if(cuitEmpleados != "" and nombreEmpleados != "" and dniEmpleados != "" and civilEmpleados != "" and 
			hijosEmpleados != "" and nacionalidadEmpleados != "" and telEmpleados !=""and domicilioEmpleados!= ""and mailEmpleados!="" and contratoEmpleados != ""):
			boton_modificar_empleado.config(state="disable")

			datos = (cuitEmpleados,nombreEmpleados,dniEmpleados,civilEmpleados,hijosEmpleados,
				      nacionalidadEmpleados,telEmpleados,domicilioEmpleados,mailEmpleados,contratoEmpleados)

			tabla = conexion.cursor()
			tabla.execute("INSERT INTO Empleados(cuitEmpleados,nombreEmpleados,dniEmpleados,civilEmpleados,hijosEmpleados,nacionalidadEmpleados,telEmpleados,domicilioEmpleados,mailEmpleados,contratoEmpleados)VALUES(?,?,?,?,?,?,?,?,?,?)",datos)
			conexion.commit()
			messagebox.showinfo("LifeHealth","Guardado con éxito")
			limpiar_empleados()
			boton_modificar_empleado.config(state="normal")
		else:
			messagebox.showwarning("LifeHealth","Complete todos los campos")

	boton_guardar_empleado = ttk.Button(frame_empleados,text="GUARDAR",style="botonNavegacion.TButton",command = guardar_empleados)
	boton_guardar_empleado.pack(side=LEFT,padx=20,pady=10)

	def eliminar_empleados():
		boton_guardar_empleado.config(state="normal")
		legajoEmpleados = entry_legajo_empleados.get()
		datos = (legajoEmpleados,)
		tabla=conexion.cursor()
		tabla.execute("DELETE FROM Empleados WHERE legajoEmpleados =?",datos)
		conexion.commit()
		messagebox.showinfo("LifeHealth","Eliminado con éxito")
		combo.pack_forget()
		limpiar_empleados()
		
	boton_eliminar_empleado = ttk.Button(frame_empleados,text="ELIMINAR",style="botonNavegacion.TButton",command = eliminar_empleados)
	boton_eliminar_empleado.pack(side=LEFT,padx=20,pady=10)
	boton_eliminar_empleado.config(state="disabled")

	def limpiar_empleados():
		entry_busqueda_empleados.delete(0,END)
		entry_legajo_empleados.config(state="normal")
		entry_legajo_empleados.delete(0,END)
		entry_legajo_empleados.config(state="readonly")
		entry_cuit_empleados.delete(0,END)
		entry_nombre_empleados.delete(0,END)
		entry_dni_empleados.delete(0,END)
		entry_civil_empleados.delete(0,END)
		entry_hijos_empleados.delete(0,END)
		entry_nacionalidad_empleados.delete(0,END)
		entry_tel_empleados.delete(0,END)
		entry_domicilio_empleados.delete(0,END)
		entry_mail_empleados.delete(0,END)
		entry_contrato_empleados.delete(0,END)
				
		boton_guardar_empleado.config(state="normal")
		#boton_modificar_empleado.config(state="disable")
		#boton_eliminar_empleado.config(state="disable")
		combo.pack_forget()
	boton_limpiar_empleado = ttk.Button(frame_empleados,text="LIMPIAR",style="botonNavegacion.TButton",command = limpiar_empleados)
	boton_limpiar_empleado.pack(side=LEFT,padx=20,pady=20)

	def volverPrincipalEmpleados():
		global imagen_pil_volver_empleado
		borrarFrames()
		principal()

	imagen_pil_volver_empleado= Image.open("iconos/btnVolver.png")
	imagen_resize_volver_empleado = imagen_pil_volver_empleado.resize((30,30))
	imagen_tk_volver_empleado= ImageTk.PhotoImage(imagen_resize_volver_empleado)

	boton_volver_empleado = ttk.Button(frame_empleados,text="VOLVER",style="botonNavegacion.TButton",command = volverPrincipalEmpleados)
	boton_volver_empleado.config(image=imagen_tk_volver_empleado,compound=LEFT)
	boton_volver_empleado.image = imagen_tk_volver_empleado
	boton_volver_empleado.pack(side=LEFT,padx=20,pady=20)
	
def compras(frame_contenido):
	global frame_compras
	frame_compras = ttk.Frame(frame_contenido,style='fondo.TFrame')
	frame_compras.pack(fill=BOTH,expand=1)
	frame_contenido_compras = ttk.Frame(frame_compras,style='navegacion.TFrame')
	frame_contenido_compras.pack(side=LEFT,fill=Y)
	listbox_productos = Listbox(frame_compras)
	listbox_productos.place(x=500,y=100,width=700,height=400)
	
	frame_botones_compras = ttk.Frame(frame_compras,style='navegacion.TFrame')
	frame_botones_compras.pack(side=BOTTOM,fill=X,pady=5,padx=5)

	label_compras = ttk.Label(frame_contenido_compras,text="Registrar pedidos",style='subTitulo.TLabel')
	label_compras.pack(anchor=NW,padx=10,pady=20)

	label_compras_buscar = ttk.Label(frame_contenido_compras,text="Buscar N° Pedido:",style='labelNavegacion.TLabel')
	label_compras_buscar.pack(anchor=NW,padx=10,pady=5)
	entry_compras_buscar = ttk.Label(frame_contenido_compras,style='labelNavegacion.TLabel',width=20)
	entry_compras_buscar.pack(anchor=NW,padx=10,pady=5)

	label_compras_numero = ttk.Label(frame_contenido_compras,text="N° Pedido°:",style='labelNavegacion.TLabel')
	label_compras_numero.pack(anchor=NW,padx=10,pady=5)
	entry_compras_numero = ttk.Label(frame_contenido_compras,style='labelNavegacion.TLabel',width=20)
	entry_compras_numero.pack(anchor=NW,padx=10,pady=5)

	label_compras_proveedor = ttk.Label(frame_contenido_compras,text="Proveedor:",style='labelNavegacion.TLabel')
	label_compras_proveedor.pack(anchor=NW,padx=10,pady=5)
	entry_compras_proveedor = ttk.Label(frame_contenido_compras,style='labelNavegacion.TLabel',width=20)
	entry_compras_proveedor.pack(anchor=NW,padx=10,pady=5)

	label_compras_producto = ttk.Label(frame_contenido_compras,text="Producto:",style='labelNavegacion.TLabel')
	label_compras_producto.pack(anchor=NW,padx=10,pady=5)
	entry_compras_producto = ttk.Label(frame_contenido_compras,style='labelNavegacion.TLabel',width=20)
	entry_compras_producto.pack(anchor=NW,padx=10,pady=5)

	label_compras_cantidad = ttk.Label(frame_contenido_compras,text="Cantidad:",style='labelNavegacion.TLabel')
	label_compras_cantidad.pack(anchor=NW,padx=10,pady=5)
	entry_compras_cantidad = ttk.Label(frame_contenido_compras,style='labelNavegacion.TLabel',width=20)
	entry_compras_cantidad.pack(anchor=NW,padx=10,pady=5)

	label_fecha_compras = ttk.Label(frame_contenido_compras,text="Fecha:",style='labelNavegacion.TLabel')
	label_fecha_compras.pack(anchor=NW,padx=10,pady=5)
	entry_fecha_compras = ttk.Label(frame_contenido_compras,style='labelNavegacion.TLabel',width=20)
	entry_fecha_compras.pack(anchor=NW,padx=10,pady=5)


	def buscar_compra():
		pass

	boton_buscar_compras = ttk.Button(frame_contenido_compras,text="BUSCAR",style="botonNavegacion.TButton",command = buscar_compra)
	boton_buscar_compras.pack(padx=25,pady=20)


	def actualizar_compra():
		pass

	boton_actualizar_compras = ttk.Button(frame_botones_compras,text="ACTUALIZAR",style="botonNavegacion.TButton",command = actualizar_compra)
	boton_actualizar_compras.pack(side=LEFT,padx=25,pady=10)


	def agregar_compra():
		pass

	boton_agregar_compras = ttk.Button(frame_botones_compras,text="AGREGAR",style="botonNavegacion.TButton",command = agregar_compra)
	boton_agregar_compras.pack(side=LEFT,padx=25,pady=10)

	def sacar_compra():
		pass


	boton_sacar_compras = ttk.Button(frame_botones_compras,text="QUITAR",style="botonNavegacion.TButton",command = sacar_compra)
	boton_sacar_compras.pack(side=LEFT,padx=25,pady=10)


	def guardar_compra():
		pass

	boton_guardar_compras = ttk.Button(frame_botones_compras,text="REGISTRAR",style="botonNavegacion.TButton",command = guardar_compra)
	boton_guardar_compras.pack(side=LEFT,padx=25,pady=10)

	def anular_compra():
		pass

	boton_anular_compras = ttk.Button(frame_botones_compras,text="ANULAR",style="botonNavegacion.TButton",command = anular_compra)
	boton_anular_compras.pack(side=LEFT,padx=25,pady=10)


	def listar_pedidos():
		pass

	boton_ver_compras = ttk.Button(frame_botones_compras,text="Ver pedidos",style="botonNavegacion.TButton",command = listar_pedidos)
	boton_ver_compras.pack(side=LEFT,padx=25,pady=10)

	def volverPrincipalCompras():
			global imagen_pil_volver_compras
			borrarFrames()
			principal()

	imagen_pil_volver_compras= Image.open("iconos/btnVolver.png")
	imagen_resize_volver_compras = imagen_pil_volver_compras.resize((30,30))
	imagen_tk_volver_compras= ImageTk.PhotoImage(imagen_resize_volver_compras)

	boton_volver_compras = ttk.Button(frame_contenido_compras,text="VOLVER",style="botonNavegacion.TButton",command = volverPrincipalCompras)
	boton_volver_compras.config(image=imagen_tk_volver_compras,compound=LEFT)
	boton_volver_compras.image = imagen_tk_volver_compras
	boton_volver_compras.pack(padx=25,pady=20)
	

def ventas(frame_contenido):
	db_nombre= "LifeHealth.db"
	global imagen_pil_imprimir
	global frame_ventas

	def cargar_productos():
		global cargar_productos
		
		try:
			conexion = sqlite3.connect(db_nombre)
			cv = conexion.cursor()
			cv.execute("SELECT nombreProducto FROM productos")
			productos = cv.fetchall()

			entry_nombre["values"] = [producto[0] for producto in productos]
			if not productos:
				messagebox.showwarning(title="LifeHealth",message="No se encontró producto")
			conexion.close()
		except sqlite3.Error as e:
			messagebox.showerror("Error al cargar productos desde la base de datos",e)
	
	def actualizar_precio(event):
		global actualizar_precio
		nombre_producto = entry_nombre.get()

		try:
			conexion =sqlite3.connect(db_nombre)
			cv = conexion.cursor()
			cv.execute("SELECT precioProducto FROM productos WHERE nombreProducto = ?",(nombre_producto,))
			precio = cv.fetchone()
			if(precio):
				entry_valor.config(state="normal")
				entry_valor.delete(0,END)
				entry_valor.insert(0,precio[0])
				entry_valor.config(state="readonly")
			else:
				entry_valor.config(state="normal")
				entry_valor.delete(0,END)
				entry_valor.insert(0,"Precio no disponible ")
				entry_valor.config(state="readonly")
		except sqlite3.Error as e:
			messagebox.showerror("Error",f"Error al obtener el precio:{e}")
		finally:
			conexion.close()


	#numero_factura_actual=obtener_numero_factura_actual()
	#mostrar_numero_factura()
	
	#Frame gral
	frame_ventas = ttk.Frame(frame_contenido,style='fondo.TFrame')
	frame_ventas.pack(fill=BOTH,expand=1)

	#Frame de contrenido Label y Entry
	frame_contenido_ventas = ttk.Frame(frame_ventas,style="frameTerciarios.TFrame")
	frame_contenido_ventas.pack(side=TOP,fill=X,pady=20,padx=20,ipady=10,ipadx=10)

	#Frame para tabla de venta
	treFrame = Frame(frame_ventas,bg="snow",width=800,height=250)
	treFrame.pack(fill=X,pady=20,padx=20)

	#Label y Entry
	label_ventas_titulo= LabelFrame(frame_contenido_ventas,text="Ventas",bg="SkyBlue4",font="Georgia 20 bold")
	label_ventas_titulo.grid(column=0,row=0,padx=10,pady=10)

	label_numero_factura = ttk.Label(label_ventas_titulo,text="N°Factura",style='labelNavegacion.TLabel')
	label_numero_factura.grid(column=3,row=1,padx=10,pady=10,sticky=W)
	numero_factura= StringVar()


	entry_numero_factura = ttk.Entry(label_ventas_titulo,style="entradasNavegacion.TLabel",width=35,state="readonly")
	entry_numero_factura.grid(column=4,row=1,padx=5,pady=5,sticky=W)

	label_nombre = ttk.Label(label_ventas_titulo,text="Producto",style='labelNavegacion.TLabel')
	label_nombre.grid(column=5,row=1,padx=10,pady=10,sticky=W)
	entry_nombre = ttk.Combobox(label_ventas_titulo,style="entradasNavegacion.TLabel",width=35,state="readonly")
	entry_nombre.grid(column=6,row=1,padx=5,pady=5,sticky=W)

	cargar_productos()

	label_valor = ttk.Label(label_ventas_titulo,text="Precio",style='labelNavegacion.TLabel')
	label_valor.grid(column=5,row=2,padx=10,pady=10,sticky=W)
	entry_valor = ttk.Entry(label_ventas_titulo,style="entradasNavegacion.TLabel",width=15,state="readonly")
	entry_valor.grid(column=6,row=2,padx=5,pady=5,sticky=W)

	entry_nombre.bind("<<ComboboxSelected>>",actualizar_precio)

	label_cantidad = ttk.Label(label_ventas_titulo,text="Cantidad:",style='labelNavegacion.TLabel',state="readonly")
	label_cantidad.grid(column=5,row=3,padx=10,pady=10,sticky=W)
	entry_cantidad = ttk.Entry(label_ventas_titulo,style='entradasNavegacion.TLabel',width=10)
	entry_cantidad.grid(column=6,row=3,pady=5,sticky=W)

	label_ventas_iva = ttk.Label(label_ventas_titulo,text="IVA:",style='labelNavegacion.TLabel',state="readonly")
	label_ventas_iva.grid(column=7,row=1,padx=10,pady=10,sticky=W)
	entry_ventas_iva = ttk.Entry(label_ventas_titulo,style='entradasNavegacion.TLabel',width=10)
	entry_ventas_iva.grid(column=8,row=1,pady=5,sticky=W)

	label_ventas_descuento = ttk.Label(label_ventas_titulo,text="Descuento:",style='labelNavegacion.TLabel',state="readonly")
	label_ventas_descuento.grid(column=7,row=2,padx=10,pady=10,sticky=W)
	entry_ventas_descuento = ttk.Entry(label_ventas_titulo,style='entradasNavegacion.TLabel',width=10)
	entry_ventas_descuento.grid(column=8,row=2,pady=5,sticky=W)
	
	#Armado de Treeviw con barra de desplazamiento
	scrol_y_v = ttk.Scrollbar(treFrame,orient=VERTICAL)
	scrol_y_v.pack(side=RIGHT,fill=Y)

	scrol_x_v = ttk.Scrollbar(treFrame,orient=HORIZONTAL)
	scrol_x_v.pack(side=BOTTOM,fill=X)

	tree = ttk.Treeview(treFrame,columns = ("Producto","Precio","Cantidad","Subtotal"),show="headings",height=10,yscrollcommand=scrol_y_v.set,xscrollcommand=scrol_x_v.set)
	scrol_y_v.config(command=tree.yview)
	scrol_x_v.config(command=tree.xview)

	tree.heading("#1",text="Producto")
	tree.heading("#2",text="Precio")
	tree.heading("#3",text="Cantidad")
	tree.heading("#4",text="Subtotal")
	#contenidoVenta.heading("#4",text="Descuento")
	#contenidoVenta.heading("#5",text="Subtotal")
	tree.column("Producto",anchor="center")
	tree.column("Precio",anchor="center")
	tree.column("Cantidad",anchor="center")
	#contenidoVenta.column("IVA",anchor="center")
	#contenidoVenta.column("Descuento",anchor="center")
	tree.column("Subtotal",anchor="center")

	tree.pack(expand=True,fill=BOTH)


	
	#boton_quitar_venta =ttk.Button(frame_contenido_ventas,text="QUITAR",style="botonNavegacion.TButton",command=)
	#boton_quitar_venta.grid(column=10,row=3,ipadx=5,ipady=5,padx=100,pady=5)


	label_suma_total =ttk.Label(frame_ventas,text= "Total a pagar: $ 0",style='labelNavegacion.TLabel')
	label_suma_total.pack(side=RIGHT,padx=50)
	
	
	def actualizar_total():
		total = 0.0
		for child in tree.get_children():
			subtotal = float(tree.item(child,"values")[3])
			total += subtotal

		label_suma_total.config(text=f"Total a pagar: ${total:.0f}")


	def registrar():
		producto = entry_nombre.get()
		precio = entry_valor.get()
		cantidad = entry_cantidad.get()
		if(producto and precio and cantidad):
			try:
				cantidad = int(cantidad)
				if not verificar_stock(producto,cantidad):
					messagebox.showerror("Error",f"Stock insuficiente para el producto seleccionasdo")
					return
				precio = float(precio)
				subtotal = cantidad * precio
				tree.insert("","end",values=(producto,f"{precio:.0f}",cantidad,f"{subtotal:.0f}"))

				entry_nombre.set("")
				entry_valor.config(state="normal")
				entry_valor.delete(0,END)
				entry_valor.config(state="readonly")
				entry_cantidad.delete(0,END)

				actualizar_total()

			except ValueError:
				messagebox.showerror("Error","Cantidad o precio no válidos")

		else:
			messagebox.showerror("Error","Debe completar todos los campos")
	boton_agregar_venta = ttk.Button(label_ventas_titulo,text="AGREGAR",style="botonNavegacion.TButton",command=registrar)
	boton_agregar_venta.grid(column=10,row=2,ipadx=5,ipady=5,padx=100,pady=5)


	def verificar_stock(nombre_producto,cantidad):
		try:
			conexion =sqlite3.connect(db_nombre)
			cv = conexion.cursor()
			cv.execute("SELECT stockProducto FROM productos WHERE nombreProducto = ?",(nombre_producto,))
			stock =cv.fetchone()
			if stock and stock[0] >= cantidad:
				return True
			return False
		except sqlite3.Error as e:
			messagebox.showerror("Error",f"Error al verificar el stock:{e}")
			return False
		finally:
			conexion.close()

	def obtener_total():
		total = 0.0
		for child in tree.get_children():
			subtotal = float(tree.item(child,"values")[3])
			total += subtotal 
		return total

	def abrir_ventana_pago():
		if not tree.get_children():
			messagebox.showerror("Error",f"No hay articulos para pagar")
			return
		ventana_pago = Toplevel()
		ventana_pago.title("Realizar pago")
		ventana_pago.geometry("400x400")
		ventana_pago.config(bg="SkyBlue4")
		ventana_pago.resizable(False,False)

		label_total =ttk.Label(ventana_pago,style="navegacion.TLabel",text=f"Total a pagar: ${obtener_total():.0f}")
		label_total.place(x=70,y=20)
		label_cantidad_pagada =ttk.Label(ventana_pago,style="navegacion.TLabel",text="Cantidad pagada:")
		label_cantidad_pagada.place(x=100,y=90)
		entry_cantidad_pagada =ttk.Entry(ventana_pago,style="entradasNavegacion.TLabel")
		entry_cantidad_pagada.place(x=100,y=130)
		label_cambio = ttk.Label(ventana_pago,style="navegacion.TLabel",text="")
		label_cambio.place(x=100,y=190)
	

		def calcular_cambio():
			try:
				cantidad_pagada = float(entry_cantidad_pagada.get())
				total = obtener_total()
				cambio = cantidad_pagada - total
				if cambio < 0:
					messagebox.showerror("Error", f"La cantidad pagada es insuficiente")
					return
				label_cambio.config(text=f"Vuelto ${cambio:.0f}")
			except ValueError:
				messagebox.showerror("Error", f"Cantidad pagada no válida")

		boton_calcular = ttk.Button(ventana_pago,text="Calcular vuelto",style="botonNavegacion.TButton",command=calcular_cambio)
		boton_calcular.place(x=100,y=240,width=240,height=40)
		boton_pagar = ttk.Button(ventana_pago,text="Pagar",style="botonNavegacion.TButton",command=lambda:pagar(ventana_pago,entry_cantidad_pagada,label_cambio))
		boton_pagar.place(x=100,y=300,width=240,height=40)

	boton_pagar_venta =ttk.Button(frame_ventas,text="PAGAR",style="botonNavegacion.TButton",command=abrir_ventana_pago)
	boton_pagar_venta.pack(side=LEFT,padx=20)
	

	def pagar(ventana_pago,entry_cantidad_pagada,label_cambio):
		try:
			cantidad_pagada = float(entry_cantidad_pagada.get())
			total = obtener_total()
			cambio = cantidad_pagada - total
			if cambio <0:
				messagebox.showerror("Error","La cantidad pagada es insuficiente")
				return

			conexion = sqlite3.connect(db_nombre)
			cv = conexion.cursor()
			try:
				for child in tree.get_children():
					item = tree.item(child,"values")
					nombre_producto = item[0]
					cantidad_vendida = int(item[2])
					if not verificar_stock(nombre_producto,cantidad_vendida):
						messagebox.showerror("Error",f"Stock insuficiente para el producto:{nombre_producto}")
						return
					cv.execute("INSERT INTO ventas (factura,nombre_articulo,valor_articulo,cantidad,subtotal) VALUES(?,?,?,?,?),(numero_factura_actual,nombre_producto,float(item[1],cantidad_vendida,float(item[3])")

					cv.execute("UPDATE productos SET stockProducto = stockProducto - ? where nombreProducto = ?",(nombre_producto,cantidad_vendida))
				conexion.commit()
				messagebox.showinfo("Exito","Venta registrada exitosamente")

				numero_factura_actual += 1
				mostrar_numero_factura()

				for child in tree.get_children():
					tree.delete(child)
				label_suma_total.config(text="Total a pagar: $ 0")
				ventana_pago.destroy()

			except sqlite3.Error as e:
				conexion.rollback()
				messagebox.showerror("Error",f"Error al registrar la venta:{e}")
			finally:
				conexion.close()		        
		except ValueError:
			messagebox.showerror("Error",f"Cantidad pagada no válida")

	def obtener_numero_factura_actual():
		conexion= sqlite3.connect(db_nombre)
		cv=conexion.cursor()
		try:
			cv.exectue("SELECT MAX(factura) FROM ventas")
			max_factura =cv.fetchone()[0]
			if max_factura:
				return max_factura +1
			else:
				return 1
		except sqlite3.Error as e:
			messagebox.showerror("Error",f"Error al obtener el número de factura:{e}")
			return 1
		finally:
			conexion.close()

	def mostrar_numero_factura():
		numero_factura.set(numero_factura_actual)

	def abrir_ventana_factura():
		ventana_facturas = Toplevel()
		ventana_facturas.title("Factura")
		ventana_facturas.geometry("800x500")
		ventana_facturas.config(bg="SkyBlue4")
		ventana_facturas.resize(False,False)

		facturas = ttk.Label(ventana_facturas,text="Facturas Registradas",style="subTitulo.TLabel")
		facturas.place(x=150,y=15)

		treeFrame=ttk.Frame(ventana_facturas,style="navegacion.TFrame")
		treeFrame.place(x=10,y=100,width=780,height=380)

		scrol_y_v = ttk.Scrollbar(treeFrame,orient=VERTICAL)
		scrol_y_v.pack(side=RIGHT,fill=Y)

		scrol_x_v = ttk.Scrollbar(treeFrame,orient=HORIZONTAL)
		scrol_x_v.pack(side=BOTTOM,fill=X)

		contenidoFactura = ttk.Treeview(treeFrame,columns = ("ID","Factura","Producto","Precio","Cantidad","Subtotal"),show="headings",height=10,yscrollcommand=scrol_y_v.set,xscrollcommand=scrol_x_v.set)
		scrol_y_v.config(command=contenidoFactura.yview)
		scrol_x_v.config(command=contenidoFactura.xview)

		contenidoFactura.heading("#1",text="ID")
		contenidoFactura.heading("#2",text="Factura")
		contenidoFactura.heading("#3",text="Producto")
		contenidoFactura.heading("#4",text="Precio")
		contenidoFactura.heading("#5",text="Cantidad")
		contenidoFactura.heading("#6",text="Subtotal")

		contenidoFactura.column("ID",width=70,anchor="center")
		contenidoFactura.column("Factura",width=100,anchor="center")
		contenidoFactura.column("Producto",width=200,anchor="center")
		contenidoFactura.column("Precio",width=130,anchor="center")
		contenidoFactura.column("Cantidad",width=70,anchor="center")
		contenidoFactura.column("Subtotal",width=130,anchor="center")

		contenidoFactura.pack(expand=True,fill=BOTH)
		cargar_facturas(contenidoFactura)
	boton_ver_factura =ttk.Button(frame_ventas,text="Ver Facturas",style="botonNavegacion.TButton",command=abrir_ventana_factura)
	boton_ver_factura.pack(side=LEFT,padx=20)


	def cargar_facturas(tree):
		try:
			conexion=sqlite3.connect(db_nombre)
			cv=conexion.cursor()
			cv.execute("SELECT * FROM ventas")
			facturas=cv.fetchall()
			for factura in facturas:
				tree.insert("", "end", values=factura)
			conexion.close()
		except sqlite3.Error as e:
			messagebox.showerror("Error",f"Error al cargar las facturas: {e}")


	
	label_ventas_fecha = ttk.Label(label_ventas_titulo,text="Fecha:",style='labelNavegacion.TLabel')
	label_ventas_fecha.grid(column=3,row=2,padx=10,pady=10,sticky=W)
	entry_ventas_fecha = ttk.Entry(label_ventas_titulo,style='entradasNavegacion.TLabel',width=15)
	entry_ventas_fecha.grid(column=4,row=2,pady=5,sticky=W)

	label_ventas_cliente = ttk.Label(label_ventas_titulo,text="Cliente",style='labelNavegacion.TLabel')
	label_ventas_cliente.grid(column=3,row=3,padx=10,pady=10,sticky=W)
	entry_ventas_cliente = ttk.Combobox(label_ventas_titulo,style="entradasNavegacion.TLabel",width=35,state="readonly")
	entry_ventas_cliente.grid(column=4,row=3,padx=5,pady=5,sticky=W)
	
	
	def imprimirFactura():
		global imagen_pil_imprimir
		pass

	imagen_pil_imprimir= Image.open("iconos/btnImprimir.png")
	imagen_resize_imprimir = imagen_pil_imprimir.resize((40,40))
	imagen_tk_imprimir= ImageTk.PhotoImage(imagen_resize_imprimir)

	boton_venta_imprimir = ttk.Button(frame_contenido_ventas,style='botonNavegacion.TButton',command=imprimirFactura)
	boton_venta_imprimir.config(image=imagen_tk_imprimir)
	boton_venta_imprimir.image = imagen_tk_imprimir
	boton_venta_imprimir.grid(column=10,row=1,padx=600,pady=20)

	
	def volverPrincipalVentas():
		global imagen_pil_volver_ventas
		borrarFrames()
		principal()

	imagen_pil_volver_ventas= Image.open("iconos/btnVolver.png")
	imagen_resize_volver_ventas = imagen_pil_volver_ventas.resize((30,30))
	imagen_tk_volver_ventas= ImageTk.PhotoImage(imagen_resize_volver_ventas)

	boton_volver_ventas = ttk.Button(frame_ventas,text="VOLVER",style="botonNavegacion.TButton",command = volverPrincipalVentas)
	boton_volver_ventas.config(image=imagen_tk_volver_ventas,compound=LEFT)
	boton_volver_ventas.image = imagen_tk_volver_ventas
	boton_volver_ventas.pack(side=LEFT,padx=20)

	def venderVenta():
		pass

	boton_vender = ttk.Button(frame_ventas,text="PAGAR",style="botonNavegacion.TButton",command=venderVenta)
	boton_vender.pack(side=LEFT,padx=20)

	label_suma_total = ttk.Label(frame_ventas,text="Total a pagar: $ 0 ",style='labelNavegacion.TLabel')
	label_suma_total.pack(side=RIGHT,padx=70)

def inventario(frame_contenido):
	db_nombre="LifeHealth"

	global frame_inventario
	borrarFrames()
	frame_inventario = ttk.Frame(frame_contenido,style='frameSecundarios.TFrame')
	frame_inventario.pack(fill=BOTH,expand=1)

	frame_contenido_inventario =ttk.Frame(frame_inventario,style="frameTerciarios.TFrame")
	frame_contenido_inventario.pack(side=LEFT,fill=Y)

	frame_botones_inventario =ttk.Frame(frame_inventario,style="frameSecundarios.TFrame")
	frame_botones_inventario.pack(side=BOTTOM,pady=20,padx=50)

	listbox_productos = Listbox(frame_inventario)
	listbox_productos.place(x=550,y=290,width=300,height=300)

	scrol_y_p = ttk.Scrollbar(listbox_productos,orient=VERTICAL)
	scrol_y_p.pack(side=RIGHT,fill=Y)
	scrol_x_p = ttk.Scrollbar(listbox_productos,orient=HORIZONTAL)
	scrol_x_p.pack(side=BOTTOM,fill=X)

	scrol_y_p.config(command=listbox_productos.yview)
	scrol_x_p.config(command=listbox_productos.xview)

	

	now=datetime.now()
	def mostrarProducto(evento):
		indice=listbox_productos.curselection()[0]
		mensaje=listbox_productos.get(indice)
		messagebox.showinfo("LifeHealth",mensaje)
		
	listbox_productos.bind("<<ListboxSelect>>",mostrarProducto)

	label_registrar_producto = LabelFrame(frame_contenido_inventario,text="Registrar producto",bg="SkyBlue4",font="Georgia 20 bold")
	label_registrar_producto.grid(row=0,column=0,ipady=5,ipadx=5,pady=20,padx=10,sticky=NW)

	label_buscar_producto = ttk.Label(label_registrar_producto,text="Buscar producto",style="labelNavegacion.TLabel")
	label_buscar_producto.grid(row=1,column=0,ipady=5,ipadx=5,pady=5,padx=10,sticky=NW)
	entry_buscar_producto = ttk.Entry(label_registrar_producto,style="entradasNavegacion.TLabel",width=35)
	entry_buscar_producto.grid(row=1,column=1,ipady=5,ipadx=5,pady=5,padx=10,sticky=NW)

	label_codigo_producto = ttk.Label(label_registrar_producto,text="Código",style="labelNavegacion.TLabel")
	label_codigo_producto.grid(row=2,column=0,ipady=5,ipadx=5,pady=5,padx=10,sticky=NW)
	entry_codigo_producto = ttk.Entry(label_registrar_producto,style="entradasNavegacion.TLabel",width=35)
	entry_codigo_producto.grid(row=2,column=1,ipady=5,ipadx=5,pady=5,padx=10,sticky=NW)
	entry_codigo_producto.config(state="readonly")

	label_nombre_producto = ttk.Label(label_registrar_producto,text="Nombre",style="labelNavegacion.TLabel")
	label_nombre_producto.grid(row=3,column=0,ipady=5,ipadx=5,pady=5,padx=10,sticky=NW)
	entry_nombre_producto = ttk.Entry(label_registrar_producto,style="entradasNavegacion.TLabel",width=35)
	entry_nombre_producto.grid(row=3,column=1,ipady=5,ipadx=5,pady=5,padx=10,sticky=NW)

	label_categoria_producto = ttk.Label(label_registrar_producto,text="Categoria",style="labelNavegacion.TLabel")
	label_categoria_producto.grid(row=4,column=0,ipady=5,ipadx=5,pady=5,padx=10,sticky=NW)
	entry_categoria_producto = ttk.Entry(label_registrar_producto,style="entradasNavegacion.TLabel",width=35)
	entry_categoria_producto.grid(row=4,column=1,ipady=5,ipadx=5,pady=5,padx=10,sticky=NW)

	label_marca_producto = ttk.Label(label_registrar_producto,text="Marca",style="labelNavegacion.TLabel")
	label_marca_producto.grid(row=5,column=0,ipady=5,ipadx=5,pady=5,padx=10,sticky=NW)
	entry_marca_producto = ttk.Entry(label_registrar_producto,style="entradasNavegacion.TLabel",width=35)
	entry_marca_producto.grid(row=5,column=1,ipady=5,ipadx=5,pady=5,padx=10,sticky=NW)

	label_modelo_producto = ttk.Label(label_registrar_producto,text="Modelo",style="labelNavegacion.TLabel")
	label_modelo_producto.grid(row=6,column=0,ipady=5,ipadx=5,pady=5,padx=10,sticky=NW)
	entry_modelo_producto = ttk.Entry(label_registrar_producto,style="entradasNavegacion.TLabel",width=35)
	entry_modelo_producto.grid(row=6,column=1,ipady=5,ipadx=5,pady=5,padx=10,sticky=NW)

	label_fv_producto = ttk.Label(label_registrar_producto,text="Fecha de vencimiento",style="labelNavegacion.TLabel")
	label_fv_producto.grid(row=7,column=0,ipady=5,ipadx=5,pady=5,padx=10,sticky=NW)
	entry_fv_producto = ttk.Entry(label_registrar_producto,style="entradasNavegacion.TLabel",width=35)
	entry_fv_producto.grid(row=7,column=1,ipady=5,ipadx=5,pady=5,padx=10,sticky=NW)

	label_precio_producto = ttk.Label(label_registrar_producto,text="Precio",style="labelNavegacion.TLabel")
	label_precio_producto.grid(row=8,column=0,ipady=5,ipadx=5,pady=5,padx=10,sticky=NW)
	entry_precio_producto = ttk.Entry(label_registrar_producto,style="entradasNavegacion.TLabel",width=35)
	entry_precio_producto.grid(row=8,column=1,ipady=5,ipadx=5,pady=5,padx=10,sticky=NW)

	label_costo_producto = ttk.Label(label_registrar_producto,text="Costo",style="labelNavegacion.TLabel")
	label_costo_producto.grid(row=9,column=0,ipady=5,ipadx=5,pady=5,padx=10,sticky=NW)
	entry_costo_producto = ttk.Entry(label_registrar_producto,style="entradasNavegacion.TLabel",width=35)
	entry_costo_producto.grid(row=9,column=1,ipady=5,ipadx=5,pady=5,padx=10,sticky=NW)

	label_stock_producto = ttk.Label(label_registrar_producto,text="Stock",style="labelNavegacion.TLabel")
	label_stock_producto.grid(row=10,column=0,ipady=5,ipadx=5,pady=5,padx=10,sticky=NW)
	entry_stock_producto = ttk.Entry(label_registrar_producto,style="entradasNavegacion.TLabel",width=35)
	entry_stock_producto.grid(row=10,column=1,ipady=5,ipadx=5,pady=5,padx=10,sticky=NW)

	label_proveedores_producto = ttk.Label(label_registrar_producto,text="Proveedores",style="labelNavegacion.TLabel")
	label_proveedores_producto.grid(row=11,column=0,ipady=5,ipadx=5,pady=5,padx=10,sticky=NW)
	entry_proveedores_producto = ttk.Entry(label_registrar_producto,style="entradasNavegacion.TLabel",width=35)
	entry_proveedores_producto.grid(row=11,column=1,ipady=5,ipadx=5,pady=5,padx=10,sticky=NW)

	treFrame=ttk.Frame(frame_inventario,style="navegacion.TFrame")
	treFrame.place(x=550,y=10,width=780,height=250)

	scrol_y_i = ttk.Scrollbar(treFrame,orient=VERTICAL)
	scrol_y_i.pack(side=RIGHT,fill=Y)

	scrol_x_i = ttk.Scrollbar(treFrame,orient=HORIZONTAL)
	scrol_x_i.pack(side=BOTTOM,fill=X)

	tre= ttk.Treeview(treFrame,columns=("ID","PRODUCTO","PROVEEDOR","PRECIO","COSTO","STOCK"),show="headings",height=10,yscrollcommand=scrol_y_i.set,xscrollcommand=scrol_x_i.set)
	scrol_y_i.config(command=tre.yview)
	scrol_x_i.config(command=tre.xview)

	tre.heading("ID",text="id")
	tre.heading("PRODUCTO",text="Producto")
	tre.heading("PROVEEDOR",text="Proveedor")
	tre.heading("PRECIO",text="Precio")
	tre.heading("COSTO",text="Costo")
	tre.heading("STOCK",text="Stock")
		
	tre.column("ID",width=70,anchor="center")
	tre.column("PRODUCTO",width=100,anchor="center")
	tre.column("PROVEEDOR",width=200,anchor="center")
	tre.column("PRECIO",width=130,anchor="center")
	tre.column("COSTO",width=70,anchor="center")
	tre.column("STOCK",width=20,anchor="center")
	
	tre.pack(expand=True,fill=BOTH)
		
	def buscarProducto():
		if(entry_buscar_producto.get() == ""):
			messagebox.showwarning(title="LifeHealth",message="Ingrese algo que buscar")
		else:
			buscar_producto = (entry_buscar_producto.get(),)
			tabla=conexion.cursor()
			tabla.execute("SELECT * FROM productos WHERE codigoProducto=?",buscar_producto)
			datos = tabla.fetchall()

			entry_codigo_producto.config(state="normal")
			entry_codigo_producto.delete(0,END)
			entry_nombre_producto.delete(0,END)
			entry_categoria_producto.delete(0,END)
			entry_marca_producto.delete(0,END)
			entry_modelo_producto.delete(0,END)
			entry_fv_producto.delete(0,END)
			entry_precio_producto.delete(0,END)
			entry_costo_producto.delete(0,END)
			entry_stock_producto.delete(0,END)
			entry_proveedores_producto.delete(0,END)

			boton_modificar_producto.config(state="normal")
			boton_eliminar_producto.config(state="normal")

			if(len(datos)>0):
				boton_guardar_producto.config(state="disabled")
				for dato in datos:
					codigoProducto=dato[0]
					nombreProducto=dato[1]
					categoriaProducto=dato[2]
					marcaProducto=dato[3]
					modeloProducto=dato[4]
					fvProducto=dato[5]
					precioProducto=dato[6]
					costoProducto=dato[7]
					stockProducto=dato[8]
					proveedoresProducto=dato[9]    
					entry_codigo_producto.insert(END,codigoProducto)
					entry_nombre_producto.insert(END,nombreProducto)
					entry_categoria_producto.insert(END,categoriaProducto)
					entry_marca_producto.insert(END,marcaProducto)
					entry_modelo_producto.insert(END,modeloProducto)
					entry_fv_producto.insert(END,fvProducto)
					entry_precio_producto.insert(END,precioProducto)
					entry_costo_producto.insert(END,costoProducto)
					entry_stock_producto.insert(END,stockProducto)
					entry_proveedores_producto.insert(END,proveedoresProducto)

			else:
				messagebox.showwarning("LifeHealth","No se encrontró producto")
				entry_codigo_producto.config(state="readonly")
	boton_buscar_producto = ttk.Button(frame_botones_inventario,text="BUSCAR",style="botonNavegacion.TButton",command = buscarProducto)
	boton_buscar_producto.pack(side=LEFT,padx=2,pady=20)

	#Agregar
	def guardarProducto():
		boton_guardar_producto.config(state="normal")
		nombreProducto= entry_nombre_producto.get()
		categoriaProducto= entry_categoria_producto.get()
		marcaProducto = entry_marca_producto.get()
		modeloProducto = entry_modelo_producto.get()
		fvProducto = entry_fv_producto.get()
		precioProducto = entry_precio_producto.get()
		costoProducto = entry_costo_producto.get()
		stockProducto = entry_stock_producto.get()
		proveedoresProducto = entry_proveedores_producto.get()
		if(nombreProducto != "" and categoriaProducto != "" and marcaProducto != "" and modeloProducto != ""and fvProducto !="" and precioProducto != "" and costoProducto != "" and stockProducto != "" and proveedoresProducto != ""):
			datos = (nombreProducto,categoriaProducto,marcaProducto,modeloProducto,fvProducto,precioProducto,costoProducto,stockProducto,proveedoresProducto)
			tabla = conexion.cursor()
			tabla.execute("INSERT INTO productos(nombreProducto,categoriaProducto,marcaProducto,modeloProducto,fvProducto,precioProducto,costoProducto,stockProducto,proveedoresProducto)VALUES(?,?,?,?,?,?,?,?,?)",datos)
			conexion.commit()
			messagebox.showinfo("LifeHealth","Guardado con éxito")
			limpiarProducto()
			listarProducto()
		else:
			messagebox.showwarning("LifeHealth","Complete todos los campos")
	boton_guardar_producto = ttk.Button(frame_botones_inventario,text="GUARDAR",style="botonNavegacion.TButton",command = guardarProducto)
	boton_guardar_producto.pack(side=LEFT,padx=2,pady=20)

	#Modificar
	def modificarProducto():
		boton_guardar_producto.config(state="normal")
		codigoProducto = entry_codigo_producto.get()
		nombreProducto= entry_nombre_producto.get()
		categoriaProducto= entry_categoria_producto.get()
		marcaProducto = entry_marca_producto.get()
		modeloProducto = entry_modelo_producto.get()
		fvProducto = entry_fv_producto.get()
		precioProducto = entry_precio_producto.get()
		costoProducto = entry_costo_producto.get()
		stockProducto = entry_stock_producto.get()
		proveedoresProducto = entry_proveedores_producto.get()
		datos = (nombreProducto,categoriaProducto,marcaProducto,modeloProducto,fvProducto,precioProducto,costoProducto,stockProducto,proveedoresProducto,codigoProducto)
		tabla=conexion.cursor()
		tabla.execute("UPDATE productos SET nombreProducto=?,categoriaProducto=?,marcaProducto=?,modeloProducto=?,fvProducto=?,precioProducto=?,costoProducto=?,stockProducto=?,proveedoresProducto=? WHERE codigoProducto =?",datos)
		conexion.commit()
		messagebox.showinfo("LifeHealth","Modificado con éxito")
		limpiarProducto()
		listarProducto()
	boton_modificar_producto = ttk.Button(frame_botones_inventario,text="MODIFICAR",style="botonNavegacion.TButton",command = modificarProducto)
	boton_modificar_producto.pack(side=LEFT,padx=2,pady=20)
	boton_modificar_producto.config(state="disabled")
	def eliminarProducto():
		boton_guardar_producto.config(state="normal")
		codigoProducto = entry_codigo_producto.get()
		datos = (codigoProducto,)
		tabla=conexion.cursor()
		tabla.execute("DELETE FROM productos WHERE codigoProducto =?",datos)
		conexion.commit()
		messagebox.showinfo("LifeHealth","Eliminado con éxito")
		limpiarProducto()
		listarProducto()
	boton_eliminar_producto = ttk.Button(frame_botones_inventario,text="ELIMINAR",style="botonNavegacion.TButton",command = eliminarProducto)
	boton_eliminar_producto.pack(side=LEFT,padx=2,pady=20)
	boton_eliminar_producto.config(state="disabled")

	def limpiarProducto():
		boton_guardar_producto.config(state="normal")
		entry_buscar_producto.delete(0,END)
		entry_codigo_producto.config(state="normal")
		entry_codigo_producto.delete(0,END)
		entry_codigo_producto.config(state="readonly")
		entry_nombre_producto.delete(0,END)
		entry_categoria_producto.delete(0,END)
		entry_marca_producto.delete(0,END)
		entry_modelo_producto.delete(0,END)
		entry_fv_producto.delete(0,END)
		entry_precio_producto.delete(0,END)
		entry_costo_producto.delete(0,END)
		entry_stock_producto.delete(0,END)
		entry_proveedores_producto.delete(0,END)
		boton_modificar_producto.config(state="disable")
		boton_eliminar_producto.config(state="disable")
	boton_limpiar_producto = ttk.Button(frame_botones_inventario,text="LIMPIAR",style="botonNavegacion.TButton",command = limpiarProducto)
	boton_limpiar_producto.pack(side=LEFT,padx=2,pady=20)

	def listarProducto():
		global listado
		tabla = conexion.cursor()
		tabla.execute("SELECT * FROM productos")
		listado = tabla.fetchall()

		listbox_productos.delete(0,END)

		
		for elemento in listado:

			informacion = "Código: "+str(elemento[0])+"  "+"Producto: "+elemento[1]+"  "+elemento[2]+"  "+"$"+str(elemento[6])
			listbox_productos.insert(END,informacion)

			tre.insert("","end",text=[0],values=(str(elemento[0]),elemento[1],elemento[9],str(elemento[6]),str(elemento[7]),str(elemento[8])))
			
			

	boton_listar_producto = ttk.Button(frame_botones_inventario,text="LISTAR",style="botonNavegacion.TButton",command = listarProducto)
	boton_listar_producto.pack(side=LEFT,padx=2,pady=20)

	def volverPrincipalInventario():
		global imagen_pil_volver_productos
		borrarFrames()
		principal()

	imagen_pil_volver_productos= Image.open("iconos/btnVolver.png")
	imagen_resize_volver_productos = imagen_pil_volver_productos.resize((30,30))
	imagen_tk_volver_productos= ImageTk.PhotoImage(imagen_resize_volver_productos)

	boton_volver_producto = ttk.Button(frame_contenido_inventario,text="VOLVER",style="botonNavegacion.TButton",command = volverPrincipalInventario)
	boton_volver_producto.config(image=imagen_tk_volver_productos,compound=LEFT)
	boton_volver_producto.image = imagen_tk_volver_productos
	boton_volver_producto.grid(row=12,column=0,columnspan=2,pady=30)

def reportes(frame_contenido):
	global frame_reportes
	frame_reportes = ttk.Frame(frame_contenido,style='fondo.TFrame')
	frame_reportes.pack(fill=BOTH,expand=1)
	#label_reportes = ttk.Label(frame_reportes,text="Reportes",style='titulo.TLabel')
	#label_reportes.pack()

	frame_ventas_totales =ttk.Frame(frame_reportes,style="navegacion.TFrame")
	frame_ventas_totales.place(x=20,y=20,width=650,height=650)

	frame_ganancias =ttk.Frame(frame_reportes,style="navegacion.TFrame")
	frame_ganancias.place(x=700,y=20,width=650,height=650)	
	
	frame_contenido_ventas = ttk.Frame(frame_ventas_totales,style="fondo.TFrame")
	frame_contenido_ventas.place(x=22,y=10,width=600,height=300)

	frame_contenido_ganancias = ttk.Frame(frame_ganancias,style="fondo.TFrame")
	frame_contenido_ganancias.place(x=22,y=10,width=600,height=300)

	frame_tabla_ventas = Frame(frame_ventas_totales)
	frame_tabla_ventas.place(x=20,y=330,width=600,height=300)

	frame_tabla_ganancias = Frame(frame_ganancias)
	frame_tabla_ganancias.place(x=20,y=330,width=600,height=300)

def usuarios(frame_contenido):
	global frame_usuarios
	frame_usuarios = ttk.Frame(frame_contenido,style='fondo.TFrame')
	frame_usuarios.pack(fill=BOTH,expand=1)

		
	#listbox_usuarios = Listbox(frame_usuarios)
	#listbox_usuarios.place(x=200,y=100,width=700,height=400)

	#frame_botones_usuarios = ttk.Frame(frame_usuarios,style='navegacion.TFrame')
	#frame_botones_usuarios.pack(side=RIGHT,fill=Y)


	
	def verUsuariosActualizar():
		global imagen_pil_usuarios_contenido

		frame_usuarios.pack_forget()
		frame_usuarios_confirmar = ttk.Frame(frame_contenido,style='fondo.TFrame')
		frame_usuarios_confirmar.pack(fill=BOTH,expand=1)

		frame_login_usuario = ttk.Frame(frame_usuarios_confirmar,style='navegacion.TFrame')
		frame_login_usuario.pack(pady=100,ipady=50,ipadx=50)

		label_login_actualizar = ttk.Label(frame_login_usuario,text="**** Log in ****",style="tituloLogin.TLabel")
		label_login_actualizar.pack(pady=20)
	 
		label_usuario_actualizar = ttk.Label(frame_login_usuario,text="     Usuario     ",style="subTitulo.TLabel")
		label_usuario_actualizar.pack(pady=20)
		entry_usuario_actualizar = ttk.Entry(frame_login_usuario,style="entradasLogin.TLabel",width=30,show="*")
		entry_usuario_actualizar.pack(pady=10,ipadx=10,ipady=5)
		    
		label_contraseña_actualizar = ttk.Label(frame_login_usuario,text="  Contraseña  ",style="subTitulo.TLabel")
		label_contraseña_actualizar.pack(pady=20)
		entry_contraseña_actualizar = ttk.Entry(frame_login_usuario,style="entradasLogin.TLabel",width=30,show="*")
		entry_contraseña_actualizar.pack(pady=10,ipadx=10,ipady=5)

		def acutualizarUsuario():
			pass

		imagen_pil_usuarios_contenido_actualizar= Image.open("iconos/btnUsuarios.png")
		imagen_resize_usuarios = imagen_pil_usuarios_contenido_actualizar.resize((50,50))
		imagen_tk_usuarios= ImageTk.PhotoImage(imagen_resize_usuarios)

		boton_actualizar_usuario_login = ttk.Button(frame_login_usuario,text="ACTUALIZAR USUARIO",style="botonNavegacion.TButton",command = verUsuariosActualizar)
		boton_actualizar_usuario_login.config(image=imagen_tk_usuarios,compound=LEFT)
		boton_actualizar_usuario_login.image = imagen_tk_usuarios
		boton_actualizar_usuario_login.pack(pady=30,padx=10)



	imagen_pil_usuarios_contenido= Image.open("iconos/btnUsuarios.png")
	imagen_resize_usuarios = imagen_pil_usuarios_contenido.resize((50,50))
	imagen_tk_usuarios= ImageTk.PhotoImage(imagen_resize_usuarios)

	boton_actualizar_usuario = ttk.Button(frame_botones_usuarios,text="ACTUALIZAR USUARIO",style="botonNavegacion.TButton",command = verUsuariosActualizar)
	boton_actualizar_usuario.config(image=imagen_tk_usuarios,compound=TOP)
	boton_actualizar_usuario.image = imagen_tk_usuarios
	boton_actualizar_usuario.pack(pady=20,padx=10)

	
	boton_actualizar_usuario.pack(padx=20,pady=30)

def gastos(frame_contenido):
	global frame_gastos
	frame_gastos = ttk.Frame(frame_contenido,style='fondo.TFrame')
	frame_gastos.pack(fill=BOTH,expand=1)

	frame_contenido_gastos =ttk.Frame(frame_gastos,style="navegacion.TFrame")
	frame_contenido_gastos.pack(side=LEFT,fill=Y)

	frame_botones_gastos =ttk.Frame(frame_gastos,style="navegacion.TFrame")
	frame_botones_gastos.pack(fill=Y,side=RIGHT,ipadx=50)

	listbox_gastos = Listbox(frame_gastos)
	listbox_gastos.place(x=340,y=100,width=700,height=400)

	label_gastos = ttk.Label(frame_contenido_gastos,text="Registrar gastos",style="subTitulo.TLabel")
	label_gastos.pack(padx=15,pady=15)

	label_buscar_gastos =ttk.Label(frame_contenido_gastos,text="Buscar Gasto",style="labelNavegacion.TLabel")
	label_buscar_gastos.pack(anchor=NW,pady=15,padx=15)
	entry_buscar_gastos = ttk.Entry(frame_contenido_gastos,style="entradasNavegacion.TLabel",width=35)
	entry_buscar_gastos.pack(anchor=NW,padx=15,pady=15)
	
	label_id_gastos = ttk.Label(frame_contenido_gastos,text="N° de gasto",style="labelNavegacion.TLabel")
	label_id_gastos.pack(anchor=NW,pady=15,padx=15)
	entry_id_gastos = ttk.Entry(frame_contenido_gastos,style="entradasNavegacion.TLabel",width=35)
	entry_id_gastos.pack(anchor=NW,padx=15,pady=15)
	entry_id_gastos.config(state="readonly")

	label_concepto_gastos = ttk.Label(frame_contenido_gastos,text="Concepto",style="labelNavegacion.TLabel")
	label_concepto_gastos.pack(anchor=NW,pady=15,padx=15)
	entry_concepto_gastos = ttk.Entry(frame_contenido_gastos,style="entradasNavegacion.TLabel",width=35)
	entry_concepto_gastos.pack(anchor=NW,padx=15,pady=15)

	label_valor_gastos = ttk.Label(frame_contenido_gastos,text="Valor",style="labelNavegacion.TLabel")
	label_valor_gastos.pack(anchor=NW,pady=15,padx=15)
	entry_valor_gastos = ttk.Entry(frame_contenido_gastos,style="entradasNavegacion.TLabel",width=35)
	entry_valor_gastos.pack(anchor=NW,padx=15,pady=15)

	label_entidad_gastos = ttk.Label(frame_contenido_gastos,text="Entidad",style="labelNavegacion.TLabel")
	label_entidad_gastos.pack(anchor=NW,pady=15,padx=15)
	entry_entidad_gastos = ttk.Entry(frame_contenido_gastos,style="entradasNavegacion.TLabel",width=35)
	entry_entidad_gastos.pack(anchor=NW,padx=15,pady=15)

	label_fecha_gastos = ttk.Label(frame_contenido_gastos,text="Fecha",style="labelNavegacion.TLabel")
	label_fecha_gastos.pack(anchor=NW,pady=15,padx=15)
	entry_fecha_gastos = ttk.Entry(frame_contenido_gastos,style="entradasNavegacion.TLabel",width=35)
	entry_fecha_gastos.pack(anchor=NW,padx=15,pady=15)
	
	def buscarGasto():
		pass
	boton_buscar_gastos = ttk.Button(frame_botones_gastos,text="BUSCAR",style="botonNavegacion.TButton",command = buscarGasto)
	boton_buscar_gastos.pack(padx=10,pady=50)
	def ingresarGasto():
		pass
	boton_ingresar_gastos = ttk.Button(frame_botones_gastos,text="INGRESAR",style="botonNavegacion.TButton",command = ingresarGasto)
	boton_ingresar_gastos.pack(padx=10,pady=30)
	def modificarGasto():
		pass
	boton_modificar_gastos = ttk.Button(frame_botones_gastos,text="MODIFICAR",style="botonNavegacion.TButton",command = modificarGasto)
	boton_modificar_gastos.pack(padx=10,pady=30)
	def eliminarGasto():
		pass
	boton_eliminar_gastos = ttk.Button(frame_botones_gastos,text="ELIMINAR",style="botonNavegacion.TButton",command = eliminarGasto)
	boton_eliminar_gastos.pack(padx=10,pady=30)
	
	def limpiarGasto():
		pass
	boton_limpiar_gastos = ttk.Button(frame_botones_gastos,text="LIMPIAR",style="botonNavegacion.TButton",command = limpiarGasto)
	boton_limpiar_gastos.pack(padx=10,pady=30)

	def volverPrincipalGastos():
		global imagen_pil_volver_gastos
		borrarFrames()
		principal()

	imagen_pil_volver_gastos= Image.open("iconos/btnVolver.png")
	imagen_resize_volver_gastos = imagen_pil_volver_gastos.resize((30,30))
	imagen_tk_volver_gastos= ImageTk.PhotoImage(imagen_resize_volver_gastos)

	boton_volver_gastos = ttk.Button(frame_botones_gastos,text="VOLVER",style="botonNavegacion.TButton",command = volverPrincipalGastos)
	boton_volver_gastos.config(image=imagen_tk_volver_gastos,compound=LEFT)
	boton_volver_gastos.image = imagen_tk_volver_gastos
	boton_volver_gastos.pack(pady=80)
	
def acerca(frame_contenido):
	global frame_acerca
	global imagenLogo
	frame_acerca = ttk.Frame(frame_contenido,style='fondo.TFrame')
	frame_acerca.pack(fill=BOTH,expand=1)
	frame_contenido_acerca=ttk.Frame(frame_acerca,style="navegacion.TFrame")
	frame_contenido_acerca.pack(fill=Y,side=LEFT,padx=300,pady=20)
	imagenLogo=PhotoImage(file="imagenLogo.png")
	label_Logo = Label(frame_contenido_acerca,image=imagenLogo)
	label_Logo.pack(padx=90,pady=20)
	label_acerca = ttk.Label(frame_contenido_acerca,text="Comprometidos en soluciones tecnológicas innovadoras,",anchor="c",justify=RIGHT,style="subTitulo.TLabel")
	label_acerca.pack(pady=5,padx=50)
	label_acerca2 = ttk.Label(frame_contenido_acerca,text="que sastifacen las necesidades de nuestros clientes.",anchor="c",justify=RIGHT,style='subTitulo.TLabel')
	label_acerca2.pack(pady=5,padx=50)
	label_acerca3 = ttk.Label(frame_contenido_acerca,text="Proyecto LifeHealth",anchor="c",justify=RIGHT,style="labelNavegacion.TLabel")
	label_acerca3.pack(pady=5,padx=50)
	label_acerca4 = ttk.Label(frame_contenido_acerca,text="Versión 2.00",anchor="c",justify=RIGHT,style="labelNavegacion.TLabel")
	label_acerca4.pack(pady=5,padx=50)
	label_acerca5 = ttk.Label(frame_contenido_acerca,text="Última actualización: 22-07-2024",anchor="c",justify=RIGHT,style="labelNavegacion.TLabel")
	label_acerca5.pack(pady=5,padx=50)
	label_acerca6 = ttk.Label(frame_contenido_acerca,text="Soporte: ",anchor="c",justify=RIGHT,style="subTitulo.TLabel")
	label_acerca6.pack(pady=5,padx=50)
	
	label_direccion_acerca = ttk.Label(frame_contenido_acerca,text="DIRECCIÓN: Mitre 2451- Ciudad de Mendoza",anchor="c",justify=RIGHT,style='labelNavegacion.TLabel')
	label_direccion_acerca.pack(pady=5)

	label_contacto_acerca = ttk.Label(frame_contenido_acerca,text="CONTACTO: 2615534872 / 2615487219",anchor="c",justify=RIGHT,style='labelNavegacion.TLabel')
	label_contacto_acerca.pack(pady=5)

	label_mail_acerca = ttk.Label(frame_contenido_acerca,text="E-MAIL: LifeHealth2024@gmail.com",anchor="c",justify=RIGHT,style='labelNavegacion.TLabel')
	label_mail_acerca.pack(pady=5)
	
	label_derechos_acerca = Label(frame_contenido_acerca,text="Copyright 2024 - Todos los derechos reservados",font=("Calibri",12),bg="SkyBlue4",fg="black")
	label_derechos_acerca.pack(pady=5)
	
	def volverPrincipalAcerca():
		global imagen_pil_volver_acerca
		borrarFrames()
		principal()

	imagen_pil_volver_acerca= Image.open("iconos/btnVolver.png")
	imagen_resize_volver_acerca = imagen_pil_volver_acerca.resize((30,30))
	imagen_tk_volver_acerca= ImageTk.PhotoImage(imagen_resize_volver_acerca)

	boton_volver_acerca = ttk.Button(frame_contenido_acerca,text="VOLVER",style="botonNavegacion.TButton",command = volverPrincipalAcerca)
	boton_volver_acerca.config(image=imagen_tk_volver_acerca,compound=LEFT)
	boton_volver_acerca.image = imagen_tk_volver_acerca
	boton_volver_acerca.pack(side=RIGHT,padx=5)
	
ventana_principal = Tk()
misEstilos()
login_principal()
ventana_principal.mainloop()

